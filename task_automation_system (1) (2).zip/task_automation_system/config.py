"""
config.py - Central configuration and constants for the application.

Keeping all constants in one place means every module uses the same
category names, priority levels and status values.
"""
import os

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
TRAINING_DIR = os.path.join(DATA_DIR, "training")
DEFAULT_DB_PATH = os.path.join(DATA_DIR, "database.db")

CATEGORY_TRAINING_FILE = os.path.join(TRAINING_DIR, "category_training.csv")
PRIORITY_TRAINING_FILE = os.path.join(TRAINING_DIR, "priority_training.csv")


def get_db_path() -> str:
    """Return the SQLite database path.

    The environment variable TASK_DB_PATH can override the default path.
    The automated tests use this so they never touch your real data.
    """
    return os.environ.get("TASK_DB_PATH", DEFAULT_DB_PATH)


# ---------------------------------------------------------------------------
# Domain constants
# ---------------------------------------------------------------------------
APP_NAME = "TaskFlow AI"
APP_TAGLINE = "AI-Powered Task Automation & Workflow Management"

CATEGORIES = ["Work", "Study", "Personal", "Meetings", "Other"]
PRIORITIES = ["High", "Medium", "Low"]
STATUSES = ["Pending", "In Progress", "Completed", "Overdue"]

# Statuses that mean "the task is still open"
OPEN_STATUSES = ["Pending", "In Progress", "Overdue"]

PRIORITY_WEIGHT = {"High": 3, "Medium": 2, "Low": 1}

# Automation windows (in hours)
DUE_SOON_HOURS = 24        # "Due within 24 hours" notification
UPCOMING_HOURS = 72        # "Due within 3 days" notification

# If the ML priority model's confidence is below this value, the system
# falls back to the rule-based priority (and says so in the UI).
PRIORITY_ML_MIN_CONFIDENCE = 0.45

# If the ML category model's confidence is below this value the
# suggestion is reported as low-confidence and "Other" is suggested.
CATEGORY_MIN_CONFIDENCE = 0.30

DATETIME_FMT = "%Y-%m-%d %H:%M:%S"
