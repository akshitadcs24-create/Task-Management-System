"""
app.py - Streamlit user interface for TaskFlow AI
(AI-Powered Task Automation & Workflow Management System).

Run with:   streamlit run app.py

Page flow
---------
 Not logged in -> Login / Register screen
 Logged in     -> sidebar navigation:
                  Dashboard | My Tasks | Create Task | AI Insights |
                  Automation Center | Reports
Every time a logged-in page loads, the workflow automation engine runs
first, so overdue detection, reminders and alerts are always up to date.
"""
from datetime import datetime, time, timedelta

import pandas as pd
import streamlit as st

import analytics as an
import auth
import automation as auto
import database as db
import task_manager as tm
from ai_engine import get_engine
from config import APP_NAME, APP_TAGLINE, CATEGORIES, PRIORITIES, STATUSES
from ui_styles import CSS, badge, esc, kpi, page_header, priority_badge, status_badge
from utils.demo_data import load_demo_tasks
from utils.helpers import format_dt, now, time_left_text

st.set_page_config(page_title=f"{APP_NAME} | Task Automation", page_icon="✅",
                   layout="wide", initial_sidebar_state="expanded")
st.markdown(CSS, unsafe_allow_html=True)

PAGES = {
    "Dashboard": ":material/space_dashboard: Dashboard",
    "My Tasks": ":material/checklist: My Tasks",
    "Create Task": ":material/add_task: Create Task",
    "AI Insights": ":material/psychology: AI Insights",
    "Automation Center": ":material/bolt: Automation Center",
    "Reports": ":material/analytics: Reports & Analytics",
}
REMINDER_OPTIONS = {"No reminder": None, "15 minutes before": timedelta(minutes=15),
                    "1 hour before": timedelta(hours=1), "3 hours before": timedelta(hours=3),
                    "1 day before": timedelta(days=1), "2 days before": timedelta(days=2)}
AI_OPTION = "__ai__"
NOTIFICATION_LABELS = {"overdue": "Overdue", "due_24h": "Due within 24 hours",
                       "due_72h": "Due within 3 days", "reminder": "Reminder"}


# ---------------------------------------------------------------------------
# Start-up: database + AI models (cached so they load only once)
# ---------------------------------------------------------------------------
@st.cache_resource(show_spinner="Training AI models...")
def load_engine():
    return get_engine()


db.init_db()          # creates data/database.db and tables automatically
engine = load_engine()


def flash(kind: str, message: str) -> None:
    st.session_state["flash"] = (kind, message)


def show_flash() -> None:
    if "flash" in st.session_state:
        kind, message = st.session_state.pop("flash")
        getattr(st, kind)(message)


def go_to(page: str) -> None:
    st.session_state["nav"] = page


# ---------------------------------------------------------------------------
# Authentication screen
# ---------------------------------------------------------------------------
def auth_screen() -> None:
    left, right = st.columns([1.15, 1], gap="large")
    with left:
        st.markdown(f"""
        <div class="hero">
          <div class="brand"><div class="brand-logo">T</div>
            <div><div class="brand-name">{APP_NAME}</div><div class="brand-sub">{APP_TAGLINE}</div></div></div>
          <h1>Plan less. Get more done.</h1>
          <p>An intelligent task manager that categorises, prioritises and tracks your work automatically.</p>
          <ul>
            <li><b>ML categorisation</b> - TF-IDF + Logistic Regression suggests Work, Study, Personal, Meetings or Other.</li>
            <li><b>Priority prediction</b> - an ML model and a transparent rule-based score, side by side.</li>
            <li><b>Workflow automation</b> - overdue detection, deadline alerts, reminders and smart ordering.</li>
            <li><b>Analytics</b> - interactive charts and downloadable CSV reports.</li>
          </ul>
        </div>""", unsafe_allow_html=True)

    with right:
        st.markdown("<div style='height:2.2rem'></div>", unsafe_allow_html=True)
        st.markdown("<div class='page-title'>Welcome</div><div class='page-sub'>"
                    "Log in or create a free account to continue.</div>", unsafe_allow_html=True)
        show_flash()
        login_tab, register_tab = st.tabs(["Log in", "Create account"])
        with login_tab:
            with st.form("login_form"):
                username = st.text_input("Username", key="login_username")
                password = st.text_input("Password", type="password", key="login_password")
                submitted = st.form_submit_button("Log in", type="primary", use_container_width=True)
            if submitted:
                user = auth.authenticate(username, password)
                if user:
                    st.session_state["user"] = user
                    st.session_state["nav"] = "Dashboard"
                    st.rerun()
                else:
                    st.error("Invalid username or password.")
        with register_tab:
            with st.form("register_form", clear_on_submit=False):
                full_name = st.text_input("Full name", key="reg_name")
                email = st.text_input("Email (optional)", key="reg_email")
                r_user = st.text_input("Username", key="reg_username",
                                       help="3-30 characters: letters, numbers, _ or .")
                r_pass = st.text_input("Password", type="password", key="reg_password",
                                       help="At least 6 characters with a letter and a number.")
                r_conf = st.text_input("Confirm password", type="password", key="reg_confirm")
                reg = st.form_submit_button("Create account", type="primary", use_container_width=True)
            if reg:
                ok, msg = auth.register_user(r_user, r_pass, r_conf, full_name, email)
                (st.success if ok else st.error)(msg)


# ---------------------------------------------------------------------------
# Sidebar
# ---------------------------------------------------------------------------
def sidebar(user: dict, unread: int) -> str:
    with st.sidebar:
        st.markdown(f"""<div class="brand"><div class="brand-logo">T</div><div>
            <div class="brand-name">{APP_NAME}</div><div class="brand-sub">Task Automation Platform</div>
            </div></div>""", unsafe_allow_html=True)
        name = user.get("full_name") or user["username"]
        pill = f'<span class="notif-pill">{unread} new</span>' if unread else ""
        st.markdown(f"""<div class="user-chip">Signed in as<br><b>{esc(name)}</b>
            <span style="opacity:.7">@{esc(user['username'])}</span><br>
            <span style="font-size:.8rem">Notifications</span>{pill}</div>""", unsafe_allow_html=True)
        if "nav" not in st.session_state:
            st.session_state["nav"] = "Dashboard"
        page = st.radio("Navigation", list(PAGES), format_func=lambda p: PAGES[p],
                        key="nav", label_visibility="collapsed")
        st.markdown("<div style='height:1rem'></div>", unsafe_allow_html=True)
        if st.button(":material/logout: Log out", key="logout_btn"):
            for key in list(st.session_state.keys()):
                del st.session_state[key]
            flash("success", "You have been logged out.")
            st.rerun()
        st.caption(f"{format_dt(now())}")
    return page


# ---------------------------------------------------------------------------
# Shared widgets
# ---------------------------------------------------------------------------
def task_card_html(t: dict) -> str:
    deadline = t["deadline"]
    has_deadline = deadline is not None and not pd.isna(deadline)
    left = time_left_text(deadline) if has_deadline else "No deadline"
    overdue_cls = "overdue" if t["status"] == "Overdue" else ""
    ai_bits = ""
    if t.get("ai_category"):
        ai_bits = f" · AI suggested: {esc(t['ai_category'])} / {esc(t.get('ai_priority') or '-')}"
    desc = f'<div class="task-desc">{esc(t["description"])}</div>' if t.get("description") else ""
    return (f'<div class="task-title">{esc(t["title"])}</div>{desc}'
            f'{status_badge(t["status"])}{priority_badge(t["priority"])}{badge(t["category"], "b-cat")}'
            f'<div class="task-meta" style="margin-top:6px">Deadline: {format_dt(deadline) if has_deadline else "—"}'
            f' · <b class="{overdue_cls}">{esc(left)}</b>{ai_bits}</div>')


def compact_task_list(df: pd.DataFrame, empty_text: str) -> None:
    if df.empty:
        st.caption(empty_text)
        return
    for _, t in df.iterrows():
        with st.container(border=True):
            st.markdown(task_card_html(t.to_dict()), unsafe_allow_html=True)


# ---------------------------------------------------------------------------
# Page: Dashboard
# ---------------------------------------------------------------------------
def page_dashboard(user: dict, df: pd.DataFrame) -> None:
    name = (user.get("full_name") or user["username"]).split(" ")[0]
    greeting = "Good morning" if now().hour < 12 else "Good afternoon" if now().hour < 17 else "Good evening"
    st.markdown(page_header(f"{greeting}, {name}", now().strftime("%A, %d %B %Y") +
                            " · Here is your productivity overview."), unsafe_allow_html=True)
    show_flash()

    if df.empty:
        st.info("You have no tasks yet. Create your first task or load demo tasks to explore the features.")
        c1, c2, _ = st.columns([1, 1, 3])
        c1.button("Create a task", type="primary", on_click=go_to, args=("Create Task",))
        if c2.button("Load demo tasks", key="load_demo"):
            n = load_demo_tasks(user["id"], engine)
            auto.run_automation(user["id"])
            flash("success", f"{n} demo tasks loaded.")
            st.rerun()
        return

    s = an.summary_stats(df)
    cards = [
        kpi("Total tasks", s["total"], f"{s['due_this_week']} due this week", primary=True),
        kpi("Completed", s["completed"], f"on-time {s['on_time_rate']}%" if s["on_time_rate"] is not None else "—", "#16A34A"),
        kpi("In progress", s["in_progress"], "being worked on", "#1F5EFF"),
        kpi("Pending", s["pending"], f"{s['due_today']} due today", "#D97706"),
        kpi("Overdue", s["overdue"], "need attention" if s["overdue"] else "all on track", "#DC2626"),
        kpi("Completion", f"{s['completion_rate']}%", f"{s['high_priority_open']} high-priority open", "#0F1E3D"),
    ]
    st.markdown(f'<div class="kpi-grid">{"".join(cards)}</div>', unsafe_allow_html=True)
    st.progress(min(s["completion_rate"] / 100, 1.0), text=f"Overall progress: {s['completion_rate']}% of tasks completed")

    overdue = df[df["status"] == "Overdue"]
    soon = auto.upcoming_tasks(df, hours=24)
    if len(overdue):
        st.error(f"**{len(overdue)} overdue task(s):** " + ", ".join(overdue["title"].head(5)))
    if len(soon):
        st.warning(f"**{len(soon)} task(s) due within 24 hours:** " + ", ".join(soon["title"].head(5)))

    c1, c2, c3 = st.columns(3)
    c1.plotly_chart(an.fig_status_donut(df), key="d_status")
    c2.plotly_chart(an.fig_priority_bar(df), key="d_priority")
    c3.plotly_chart(an.fig_category_pie(df), key="d_category")

    c1, c2 = st.columns([1.6, 1])
    c1.plotly_chart(an.fig_productivity(df, 14), key="d_prod")
    c2.plotly_chart(an.fig_completion_gauge(s["completion_rate"]), key="d_gauge")

    c1, c2 = st.columns(2)
    with c1:
        st.markdown('<div class="section-title">Up next · automatically ordered</div>', unsafe_allow_html=True)
        queue = auto.organize_tasks(df)
        compact_task_list(queue[queue["status"] != "Completed"].head(4), "Nothing left to do!")
    with c2:
        st.markdown('<div class="section-title">Due in the next 3 days</div>', unsafe_allow_html=True)
        compact_task_list(auto.upcoming_tasks(df).head(4), "No deadlines in the next 3 days.")


# ---------------------------------------------------------------------------
# Page: My Tasks (list, filter, quick status update, edit, delete)
# ---------------------------------------------------------------------------
def _quick_status(user_id: int, task_id: int) -> None:
    new = st.session_state[f"qs_{task_id}"]
    tm.update_status(user_id, task_id, new)
    auto.run_automation(user_id)
    flash("success", f"Status updated to {new}.")


def _delete(user_id: int, task_id: int, title: str) -> None:
    if tm.delete_task(user_id, task_id):
        flash("success", f"Task '{title}' deleted.")


def edit_form(user_id: int, t: dict) -> None:
    deadline = t["deadline"] if t["deadline"] is not None and not pd.isna(t["deadline"]) else None
    with st.form(f"edit_{t['id']}"):
        title = st.text_input("Title", value=t["title"])
        description = st.text_area("Description", value=t["description"] or "", height=80)
        c1, c2, c3 = st.columns(3)
        category = c1.selectbox("Category", CATEGORIES, index=CATEGORIES.index(t["category"]))
        priority = c2.selectbox("Priority", PRIORITIES, index=PRIORITIES.index(t["priority"]))
        status = c3.selectbox("Status", STATUSES, index=STATUSES.index(t["status"]))
        c1, c2, c3 = st.columns(3)
        has_deadline = c1.checkbox("Has deadline", value=deadline is not None)
        base = deadline.to_pydatetime() if deadline is not None else now() + timedelta(days=1)
        d = c2.date_input("Deadline date", value=base.date())
        tt = c3.time_input("Deadline time", value=base.time().replace(second=0))
        c1, c2 = st.columns(2)
        urgency = c1.slider("Urgency", 1, 5, int(t["urgency"]))
        importance = c2.slider("Importance", 1, 5, int(t["importance"]))
        if st.form_submit_button("Save changes", type="primary"):
            try:
                tm.update_task(user_id, t["id"], title=title, description=description,
                               category=category, priority=priority, status=status,
                               deadline=datetime.combine(d, tt) if has_deadline else None,
                               urgency=urgency, importance=importance)
                auto.run_automation(user_id)
                flash("success", "Task updated.")
                st.rerun()
            except tm.TaskValidationError as e:
                st.error(str(e))


def page_tasks(user: dict, df: pd.DataFrame) -> None:
    st.markdown(page_header("My Tasks", "Search, filter, update and organise all of your tasks."),
                unsafe_allow_html=True)
    show_flash()
    if df.empty:
        st.info("No tasks yet.")
        st.button("Create your first task", type="primary", on_click=go_to, args=("Create Task",))
        return

    with st.container(border=True):
        c1, c2, c3, c4, c5 = st.columns([2, 1.3, 1.3, 1.3, 1.5])
        search = c1.text_input("Search", placeholder="Search title or description", key="f_search")
        f_status = c2.multiselect("Status", STATUSES, key="f_status")
        f_priority = c3.multiselect("Priority", PRIORITIES, key="f_priority")
        f_category = c4.multiselect("Category", CATEGORIES, key="f_category")
        sort = c5.selectbox("Sort by", ["Smart order (AI automation)", "Deadline", "Priority",
                                        "Newest first"], key="f_sort")

    view = df.copy()
    if search:
        mask = view["title"].str.contains(search, case=False, na=False) | \
               view["description"].str.contains(search, case=False, na=False)
        view = view[mask]
    if f_status:
        view = view[view["status"].isin(f_status)]
    if f_priority:
        view = view[view["priority"].isin(f_priority)]
    if f_category:
        view = view[view["category"].isin(f_category)]

    if sort.startswith("Smart"):
        view = auto.organize_tasks(view)
    elif sort == "Deadline":
        view = view.sort_values("deadline", na_position="last")
    elif sort == "Priority":
        view = view.assign(_p=view["priority"].map({"High": 0, "Medium": 1, "Low": 2})) \
            .sort_values(["_p", "deadline"], na_position="last").drop(columns="_p")
    else:
        view = view.sort_values("created_at", ascending=False)

    st.caption(f"Showing {len(view)} of {len(df)} tasks")
    for _, row in view.iterrows():
        t = row.to_dict()
        with st.container(border=True):
            c1, c2, c3 = st.columns([5, 1.6, 0.9], vertical_alignment="center")
            c1.markdown(task_card_html(t), unsafe_allow_html=True)
            c2.selectbox("Status", STATUSES, index=STATUSES.index(t["status"]), key=f"qs_{t['id']}",
                         on_change=_quick_status, args=(user["id"], t["id"]), label_visibility="collapsed")
            with c3.popover(":material/delete:", help="Delete task"):
                st.write(f"Delete **{t['title']}**? This cannot be undone.")
                st.button("Yes, delete", key=f"del_{t['id']}", type="primary",
                          on_click=_delete, args=(user["id"], t["id"], t["title"]))
            with st.expander("Edit task"):
                edit_form(user["id"], t)


# ---------------------------------------------------------------------------
# Page: Create Task (with live AI suggestions)
# ---------------------------------------------------------------------------
NEW_TASK_DEFAULTS = {
    "nt_title": "", "nt_desc": "", "nt_has_dl": True, "nt_urg": 3, "nt_imp": 3,
    "nt_cat": AI_OPTION, "nt_pri": AI_OPTION, "nt_status": "Pending", "nt_rem": "No reminder",
}


def _init_new_task_state() -> None:
    for key, value in NEW_TASK_DEFAULTS.items():
        st.session_state.setdefault(key, value)
    st.session_state.setdefault("nt_date", (now() + timedelta(days=1)).date())
    st.session_state.setdefault("nt_time", time(18, 0))


def _reset_new_task_state() -> None:
    for key in list(NEW_TASK_DEFAULTS) + ["nt_date", "nt_time"]:
        st.session_state.pop(key, None)


def _new_deadline():
    s = st.session_state
    return datetime.combine(s["nt_date"], s["nt_time"]) if s["nt_has_dl"] else None


def _apply_detected_deadline(dt: datetime) -> None:
    st.session_state["nt_has_dl"] = True
    st.session_state["nt_date"] = dt.date()
    st.session_state["nt_time"] = dt.time()


def _save_new_task(user_id: int) -> None:
    s = st.session_state
    title, desc = s["nt_title"].strip(), s["nt_desc"].strip()
    if not title:
        flash("error", "Please enter a task title.")
        return
    deadline = _new_deadline()
    cat = engine.suggest_category(title, desc, user_id)
    pri = engine.suggest_priority(title, desc, deadline, s["nt_urg"], s["nt_imp"])
    category = cat["label"] if s["nt_cat"] == AI_OPTION else s["nt_cat"]
    priority = pri["final"] if s["nt_pri"] == AI_OPTION else s["nt_pri"]
    delta = REMINDER_OPTIONS[s["nt_rem"]]
    reminder = deadline - delta if (deadline and delta) else None
    try:
        tm.create_task(user_id, title, desc, category, priority, deadline, s["nt_status"],
                       s["nt_urg"], s["nt_imp"], reminder, cat["label"], pri["final"])
    except tm.TaskValidationError as e:
        flash("error", str(e))
        return
    auto.run_automation(user_id)
    _reset_new_task_state()
    flash("success", f"Task '{title}' created as {category} / {priority} priority.")


def page_create(user: dict) -> None:
    st.markdown(page_header("Create Task", "Describe your task - the AI suggests a category, "
                            "priority and deadline as you type."), unsafe_allow_html=True)
    show_flash()
    _init_new_task_state()
    form_col, ai_col = st.columns([1.35, 1], gap="large")

    with form_col:
        with st.container(border=True):
            st.text_input("Task title *", key="nt_title", placeholder="e.g. Prepare slides for client meeting tomorrow")
            st.text_area("Description", key="nt_desc", height=100,
                         placeholder="Add details. Phrases like 'by Friday' or 'in 3 days' are detected automatically.")
            c1, c2, c3 = st.columns([1, 1.2, 1])
            c1.checkbox("Set a deadline", key="nt_has_dl")
            c2.date_input("Deadline date", key="nt_date", disabled=not st.session_state["nt_has_dl"])
            c3.time_input("Time", key="nt_time", disabled=not st.session_state["nt_has_dl"])
            c1, c2 = st.columns(2)
            c1.slider("Urgency (how soon must it be done?)", 1, 5, key="nt_urg")
            c2.slider("Importance (how much does it matter?)", 1, 5, key="nt_imp")

            s = st.session_state
            deadline = _new_deadline()
            has_text = bool(s["nt_title"].strip() or s["nt_desc"].strip())
            cat = engine.suggest_category(s["nt_title"], s["nt_desc"], user["id"]) if has_text else None
            pri = engine.suggest_priority(s["nt_title"], s["nt_desc"], deadline, s["nt_urg"], s["nt_imp"]) if has_text else None

            c1, c2, c3 = st.columns(3)
            ai_label = lambda o: "Use AI suggestion" if o == AI_OPTION else o
            c1.selectbox("Category", [AI_OPTION] + CATEGORIES, key="nt_cat", format_func=ai_label)
            c2.selectbox("Priority", [AI_OPTION] + PRIORITIES, key="nt_pri", format_func=ai_label)
            c3.selectbox("Status", ["Pending", "In Progress", "Completed"], key="nt_status")
            if has_text:
                final_cat = cat["label"] if s["nt_cat"] == AI_OPTION else s["nt_cat"]
                final_pri = pri["final"] if s["nt_pri"] == AI_OPTION else s["nt_pri"]
                st.caption(f"This task will be saved as **{final_cat}** with **{final_pri}** priority.")
            st.selectbox("Reminder", list(REMINDER_OPTIONS), key="nt_rem", disabled=deadline is None)
            st.button("Create task", type="primary", on_click=_save_new_task, args=(user["id"],),
                      disabled=not s["nt_title"].strip(), icon=":material/add:")

    with ai_col:
        st.markdown('<div class="section-title">AI Assistant</div>', unsafe_allow_html=True)
        if not has_text:
            st.info("Start typing a title or description to see AI suggestions.")
            return
        conf = cat["confidence"]
        note = " (low confidence → 'Other')" if cat["low_confidence"] else ""
        st.markdown(f"""<div class="ai-box"><span class="ai-tag tag-ml">Machine learning</span>
            <div class="ai-head" style="margin-top:8px">Suggested category: {esc(cat['label'])}</div>
            <div class="task-meta">{conf:.0%} confidence{note} · {esc(cat['method'])}</div></div>""",
                    unsafe_allow_html=True)
        st.plotly_chart(an.fig_probabilities(cat["probabilities"], "Category probabilities"), key="nt_cat_chart")

        ml, rule = pri["ml"], pri["rule"]
        st.markdown(f"""<div class="ai-box">
            <div><span class="ai-tag tag-ml">Machine learning</span>
              <b style="margin-left:6px">{esc(ml['label'])}</b>
              <span class="task-meta"> · {ml['confidence']:.0%} confidence</span></div>
            <div style="margin-top:8px"><span class="ai-tag tag-rule">Rule-based</span>
              <b style="margin-left:6px">{esc(rule['label'])}</b>
              <span class="task-meta"> · score {rule['score']:g} (High ≥ 60, Medium ≥ 30)</span></div>
            <div class="ai-head" style="margin-top:10px">Final priority suggestion: {esc(pri['final'])}</div>
            <div class="task-meta">Source: {esc(pri['source'])}{' · both methods agree' if pri['agree'] else ' · methods disagree - review manually'}</div>
            </div>""", unsafe_allow_html=True)
        with st.expander("Why? Rule-based breakdown"):
            for r in rule["reasons"]:
                st.write("• " + r)

        detected = engine.detect_deadline(s["nt_title"], s["nt_desc"])
        if detected:
            dt = detected["deadline"]
            st.markdown(f"""<div class="ai-box"><span class="ai-tag tag-rule">Rule-based text parser</span>
                <div class="ai-head" style="margin-top:8px">Deadline detected: {format_dt(dt)}</div>
                <div class="task-meta">Found the phrase "{esc(detected['matched'])}" in your text.</div></div>""",
                        unsafe_allow_html=True)
            st.button("Use detected deadline", on_click=_apply_detected_deadline, args=(dt,),
                      icon=":material/event:")


# ---------------------------------------------------------------------------
# Page: AI Insights (try the models + evaluation metrics)
# ---------------------------------------------------------------------------
def _report_table(report: dict) -> pd.DataFrame:
    rows = {k: v for k, v in report.items() if isinstance(v, dict)}
    out = pd.DataFrame(rows).T[["precision", "recall", "f1-score", "support"]]
    out[["precision", "recall", "f1-score"]] = out[["precision", "recall", "f1-score"]].round(2)
    out["support"] = out["support"].astype(int)
    return out


def page_ai(user: dict, df: pd.DataFrame) -> None:
    st.markdown(page_header("AI Insights", "Try the models and see exactly how they were trained "
                            "and evaluated."), unsafe_allow_html=True)
    show_flash()
    tab_try, tab_cat, tab_pri, tab_lim = st.tabs(["Try the AI", "Category model (ML)",
                                                  "Priority models (ML + rules)", "How it works & limitations"])

    with tab_try:
        text = st.text_input("Task text", value="Schedule a call with the client to discuss the project budget",
                             key="ai_try_text")
        c1, c2, c3 = st.columns(3)
        days = c1.number_input("Days until deadline", min_value=-30.0, max_value=365.0,
                               value=2.0, step=0.5, key="ai_try_days")
        urg = c2.slider("Urgency", 1, 5, 3, key="ai_try_urg")
        imp = c3.slider("Importance", 1, 5, 4, key="ai_try_imp")
        cat = engine.suggest_category(text, "", user["id"])
        pri = engine.suggest_priority(text, "", now() + timedelta(days=days), urg, imp)
        c1, c2 = st.columns(2)
        with c1:
            st.markdown(f"**Category (ML):** {cat['label']} · {cat['confidence']:.0%} confidence")
            st.plotly_chart(an.fig_probabilities(cat["probabilities"], "Category probabilities"), key="ai_c")
        with c2:
            st.markdown(f"**Priority (ML):** {pri['ml']['label']} · {pri['ml']['confidence']:.0%} · "
                        f"**Rule-based:** {pri['rule']['label']} (score {pri['rule']['score']}) · "
                        f"**Final:** {pri['final']}")
            st.plotly_chart(an.fig_probabilities(pri["ml"]["probabilities"], "Priority probabilities (ML)"), key="ai_p")
        detected = engine.detect_deadline(text)
        st.caption("Rule-based deadline detection: " +
                   (f"found '{detected['matched']}' → {format_dt(detected['deadline'])}" if detected else "no date phrase found"))

    with tab_cat:
        m = engine.category_model.metrics
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Training examples", engine.category_model.n_training_samples)
        c2.metric("Test accuracy (25% hold-out)", f"{m['test_accuracy']:.1%}")
        c3.metric("5-fold CV accuracy", f"{m['cv_mean']:.1%}", help=f"Standard deviation across folds: ± {m['cv_std']:.1%}")
        c4.metric("Classes", len(m["labels"]))
        st.markdown("**Algorithm comparison (5-fold cross-validation accuracy)**")
        st.dataframe(pd.DataFrame(m["comparison"]).T.rename(columns={"mean": "Mean accuracy", "std": "Std dev"})
                     .style.format("{:.1%}"))
        c1, c2 = st.columns(2)
        with c1:
            st.markdown("**Classification report (hold-out test set)**")
            st.dataframe(_report_table(m["report"]))
        c2.plotly_chart(an.fig_confusion_matrix(m["confusion_matrix"], m["labels"], "Confusion matrix"), key="cm_cat")
        st.markdown("**Most influential words learned per category**")
        st.dataframe(pd.DataFrame(engine.category_model.top_keywords(8)))

        st.markdown("**Personalise the model with your own tasks**")
        st.caption("Adds your tasks (with the categories you chose) to the training data and retrains a "
                   "model just for you. Kept in memory until the app restarts.")
        c1, c2, _ = st.columns([1.3, 1, 2])
        if c1.button("Retrain with my tasks", type="primary", key="personalise"):
            try:
                info = engine.personalise_category_model(user["id"], df.to_dict("records"))
                flash("success", f"Personal model trained on {info['total_samples']} examples "
                                 f"({info['user_samples']} of them are yours).")
            except ValueError as e:
                flash("error", str(e))
            st.rerun()
        if user["id"] in engine.user_category_models and c2.button("Reset to base model", key="reset_personal"):
            engine.reset_personalisation(user["id"])
            flash("success", "Using the base model again.")
            st.rerun()

    with tab_pri:
        m = engine.priority_model.metrics
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Training examples", engine.priority_model.n_training_samples)
        c2.metric("ML test accuracy", f"{m['test_accuracy']:.1%}")
        c3.metric("ML 5-fold CV accuracy", f"{m['cv_mean']:.1%}", help=f"Standard deviation across folds: ± {m['cv_std']:.1%}")
        c4.metric("Rule-based agreement with labels", f"{m['rule_based_accuracy_on_dataset']:.1%}")
        st.markdown("**ML algorithm comparison (5-fold CV)**")
        st.dataframe(pd.DataFrame(m["comparison"]).T.rename(columns={"mean": "Mean accuracy", "std": "Std dev"})
                     .style.format("{:.1%}"))
        c1, c2 = st.columns(2)
        with c1:
            st.markdown("**Classification report (hold-out test set)**")
            st.dataframe(_report_table(m["report"]))
        c2.plotly_chart(an.fig_confusion_matrix(m["confusion_matrix"], m["labels"], "Confusion matrix"), key="cm_pri")
        st.markdown("**Rule-based scoring (no machine learning)**")
        st.table(pd.DataFrame([
            ("Deadline", "Overdue +40 · ≤1 day +35 · ≤3 days +25 · ≤7 days +15 · ≤14 days +8"),
            ("Urgency (1-5)", "(urgency − 1) × 7.5  → max 30"),
            ("Importance (1-5)", "(importance − 1) × 7.5  → max 30"),
            ("Keywords", "urgent / asap / critical / today … +10 · someday / later … −10"),
            ("Result", "score ≥ 60 → High · ≥ 30 → Medium · otherwise Low"),
        ], columns=["Factor", "Points"]))

    with tab_lim:
        st.markdown("""
**Category prediction - Machine Learning**
1. Text is cleaned (lower-case, punctuation and filler words removed).
2. **TF-IDF** turns the text into numbers: words that are frequent in one task but rare overall get higher weight.
3. **Logistic Regression** learns a weight for every word per category and outputs a probability for each category.
4. If the best probability is below 30 %, the app suggests **Other** and marks it as low confidence.

**Priority prediction - two separate methods**
* **ML model:** TF-IDF of the text + numeric features (days left - log-scaled, urgency, importance) → Logistic Regression.
* **Rule-based score:** fixed points table (see the previous tab). It does *not* learn anything.
* The **final** suggestion uses the ML prediction when its confidence is ≥ 45 %, otherwise the rule-based result.

**Deadline detection** and **workflow automation** are rule-based (regular expressions and if/else logic), not ML.

**Limitations of the small dataset**
* Only 150 (category) and 132 (priority) hand-written examples, labelled by one person - the model has seen a limited vocabulary.
* Accuracy numbers are measured on very small test sets (38 and 33 examples), so they vary a lot with the random split; cross-validation is the more reliable number.
* The priority dataset is quite consistent, so the ML scores look high - real-world tasks will be messier.
* English only; spelling mistakes and very short texts ("misc", "todo") reduce accuracy.
* The models do not learn automatically from every edit - use *Retrain with my tasks* to personalise.
""")


# ---------------------------------------------------------------------------
# Page: Automation Center
# ---------------------------------------------------------------------------
def page_automation(user: dict, df: pd.DataFrame) -> None:
    st.markdown(page_header("Automation Center", "Rules that run automatically every time you open the app."),
                unsafe_allow_html=True)
    show_flash()
    unread = auto.get_notifications(user["id"], unread_only=True)
    s = an.summary_stats(df)
    cards = [
        kpi("Unread alerts", len(unread), "in-app notifications", primary=True),
        kpi("Overdue", s["overdue"], "auto-detected", "#DC2626"),
        kpi("Due in 24h", len(auto.upcoming_tasks(df, 24)), "approaching deadlines", "#D97706"),
        kpi("Due in 3 days", len(auto.upcoming_tasks(df, 72)), "upcoming", "#1F5EFF"),
        kpi("Reminders set", int(df["reminder_at"].notna().sum()) if len(df) else 0, "on open tasks", "#3B82F6"),
        kpi("Open tasks", s["total"] - s["completed"], "being tracked", "#0F1E3D"),
    ]
    st.markdown(f'<div class="kpi-grid">{"".join(cards)}</div>', unsafe_allow_html=True)

    c1, c2, _ = st.columns([1.2, 2, 2])
    if c1.button("Run automation now", type="primary", icon=":material/bolt:"):
        r = auto.run_automation(user["id"])
        flash("success", f"Checked {r['checked']} open tasks: {r['overdue_marked']} marked overdue, "
                         f"{r['restored']} restored, {r['escalated']} priorities escalated, "
                         f"{r['due_soon_alerts']} new deadline alerts, {r['reminders']} reminders.")
        st.rerun()
    escalate = c2.toggle("Auto-escalate priority near / past deadline", value=bool(user.get("auto_escalate", 1)))
    if escalate != bool(user.get("auto_escalate", 1)):
        auth.set_auto_escalate(user["id"], escalate)
        st.session_state["user"]["auto_escalate"] = int(escalate)
        st.rerun()

    tab_n, tab_q, tab_log, tab_rules = st.tabs(["Notifications", "Smart task queue", "Automation log", "Rules"])
    with tab_n:
        notes = auto.get_notifications(user["id"])
        if not notes:
            st.caption("No notifications yet. They appear when deadlines approach, pass, or reminders are due.")
        else:
            if unread and st.button(f"Mark all {len(unread)} as read", key="mark_all"):
                auto.mark_all_read(user["id"])
                st.rerun()
            for n in notes:
                c1, c2 = st.columns([8, 1], vertical_alignment="center")
                weight = "700" if not n["is_read"] else "400"
                c1.markdown(f'<div class="notif {esc(n["type"])}"><span style="font-weight:{weight}">'
                            f'{esc(n["message"])}</span><div class="when">{NOTIFICATION_LABELS.get(n["type"], n["type"])}'
                            f' · {format_dt(n["created_at"])}{"" if n["is_read"] else " · unread"}</div></div>',
                            unsafe_allow_html=True)
                if not n["is_read"] and c2.button("Read", key=f"read_{n['id']}"):
                    auto.mark_notification_read(user["id"], n["id"])
                    st.rerun()
    with tab_q:
        st.caption("Open tasks sorted automatically: smart score = priority weight × 30 + deadline pressure "
                   "(up to 50, minus 5 per day of slack) + 5 if in progress.")
        queue = auto.organize_tasks(df[df["status"] != "Completed"]) if len(df) else df
        if len(queue):
            show = queue[["smart_score", "title", "status", "priority", "category", "deadline"]].copy()
            show["time left"] = queue["deadline"].apply(time_left_text)
            st.dataframe(show, hide_index=True, column_config={
                "smart_score": st.column_config.ProgressColumn("Smart score", min_value=0, max_value=145, format="%.0f"),
                "deadline": st.column_config.DatetimeColumn("Deadline", format="DD MMM YYYY, hh:mm a"),
                "title": "Task", "status": "Status", "priority": "Priority", "category": "Category",
                "time left": "Time left"})
        else:
            st.caption("No open tasks.")
    with tab_log:
        log = auto.get_automation_log(user["id"])
        if log:
            st.dataframe(pd.DataFrame(log).rename(columns={"created_at": "Time", "action": "Action",
                                                           "details": "Details"}), hide_index=True)
        else:
            st.caption("No automatic actions yet.")
    with tab_rules:
        st.markdown("""
| # | Rule (rule-based automation) | Trigger | Action |
|---|---|---|---|
| 1 | Overdue detection | Pending / In Progress task past its deadline | Status → **Overdue**, alert, log |
| 2 | Deadline extended | Overdue task whose deadline is moved to the future | Status → **Pending**, log |
| 3 | Priority escalation *(toggle)* | Low task due within 24 h / any overdue task | Low → Medium / → High, log |
| 4 | Deadline alerts | Task due within 72 h and within 24 h | In-app notification (once per deadline) |
| 5 | Reminders | Reminder time reached | In-app reminder notification |
| 6 | Smart ordering | Every task list | Sort by smart score |
""")


# ---------------------------------------------------------------------------
# Page: Reports & Analytics
# ---------------------------------------------------------------------------
def page_reports(user: dict, df: pd.DataFrame) -> None:
    st.markdown(page_header("Reports & Analytics", "Interactive charts and downloadable CSV reports."),
                unsafe_allow_html=True)
    if df.empty:
        st.info("Reports will appear once you have tasks.")
        return
    c1, c2, _ = st.columns([1.2, 1.4, 2])
    period = c1.selectbox("Period (by creation date)", ["All time", "Last 7 days", "Last 30 days", "Last 90 days"])
    if period != "All time":
        days = int(period.split()[1])
        df = df[df["created_at"] >= pd.Timestamp(now() - timedelta(days=days))]
    stamp = now().strftime("%Y%m%d")
    c2.download_button("Download all tasks (CSV)", an.to_csv_bytes(an.export_frame(df)),
                       f"all_tasks_{stamp}.csv", "text/csv", icon=":material/download:", type="primary")
    s = an.summary_stats(df)
    cards = [kpi("Tasks in period", s["total"], period, primary=True),
             kpi("Completed", s["completed"], f"{s['completion_rate']}% completion", "#16A34A"),
             kpi("Open", s["total"] - s["completed"], f"{s['overdue']} overdue", "#D97706"),
             kpi("On-time rate", f"{s['on_time_rate']}%" if s["on_time_rate"] is not None else "—",
                 "completed before deadline", "#1F5EFF"),
             kpi("High priority open", s["high_priority_open"], "needs focus", "#DC2626"),
             kpi("Due this week", s["due_this_week"], "open tasks", "#0F1E3D")]
    st.markdown(f'<div class="kpi-grid">{"".join(cards)}</div>', unsafe_allow_html=True)

    t1, t2, t3, t4, t5 = st.tabs(["Completion report", "Pending report", "Priority-wise",
                                  "Category-wise", "Productivity"])
    with t1:
        rep = an.completion_report(df)
        st.dataframe(rep, hide_index=True)
        st.download_button("Download completion report", an.to_csv_bytes(rep), f"completion_report_{stamp}.csv",
                           "text/csv", key="dl_comp")
    with t2:
        rep = an.pending_report(df)
        st.dataframe(rep, hide_index=True)
        st.download_button("Download pending report", an.to_csv_bytes(rep), f"pending_report_{stamp}.csv",
                           "text/csv", key="dl_pend")
    with t3:
        c1, c2 = st.columns(2)
        c1.plotly_chart(an.fig_priority_bar(df), key="r_pri")
        c2.plotly_chart(an.fig_priority_by_status(df), key="r_pri_status")
        rep = an.group_report(df, "priority", PRIORITIES)
        st.dataframe(rep, hide_index=True)
        st.download_button("Download priority report", an.to_csv_bytes(rep), f"priority_report_{stamp}.csv",
                           "text/csv", key="dl_pri")
    with t4:
        c1, c2 = st.columns(2)
        c1.plotly_chart(an.fig_category_pie(df), key="r_cat")
        rep = an.group_report(df, "category", CATEGORIES)
        c2.dataframe(rep, hide_index=True)
        c2.download_button("Download category report", an.to_csv_bytes(rep), f"category_report_{stamp}.csv",
                           "text/csv", key="dl_cat")
    with t5:
        days = st.slider("Days to show", 7, 90, 30, key="prod_days")
        st.plotly_chart(an.fig_productivity(df, days), key="r_prod")
        rep = an.productivity_series(df, days)
        rep["date"] = rep["date"].dt.strftime("%Y-%m-%d")
        st.dataframe(rep, hide_index=True)
        st.download_button("Download productivity report", an.to_csv_bytes(rep), f"productivity_report_{stamp}.csv",
                           "text/csv", key="dl_prod")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main() -> None:
    user = st.session_state.get("user")
    if not user:
        auth_screen()
        return
    if auth.get_user(user["id"]) is None:   # account no longer exists
        st.session_state.clear()
        st.rerun()

    try:
        auto.run_automation(user["id"])      # workflow automation on every page load
    except Exception as e:                   # never block the UI because of automation
        st.warning(f"Automation could not run: {e}")

    unread = auto.unread_count(user["id"])
    page = sidebar(user, unread)
    df = tm.get_tasks_df(user["id"])

    if page == "Dashboard":
        page_dashboard(user, df)
    elif page == "My Tasks":
        page_tasks(user, df)
    elif page == "Create Task":
        page_create(user)
    elif page == "AI Insights":
        page_ai(user, df)
    elif page == "Automation Center":
        page_automation(user, df)
    else:
        page_reports(user, df)


main()
