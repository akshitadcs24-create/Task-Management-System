"""
models/text_utils.py - Text pre-processing shared by both ML models.

We use a SMALL custom stop-word list on purpose: scikit-learn's built-in
English list removes useful words such as "call", "bill" and "fill",
which are strong clues for the Meetings and Personal categories.
"""
import re

STOP_WORDS = {
    "a", "an", "the", "and", "or", "to", "of", "for", "in", "on", "at", "by",
    "with", "from", "my", "our", "your", "is", "are", "be", "this", "that",
    "it", "as", "up", "about", "into", "some", "i", "me", "we", "will",
}


def clean_text(text) -> str:
    """Lower-case, keep only letters/digits, remove stop words."""
    text = str(text or "").lower()
    text = re.sub(r"[^a-z0-9\s]", " ", text)
    tokens = [t for t in text.split() if t not in STOP_WORDS and len(t) > 1]
    return " ".join(tokens)
