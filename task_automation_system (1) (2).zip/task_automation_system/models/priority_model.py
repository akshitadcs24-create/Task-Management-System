"""
models/priority_model.py - Priority prediction: ML model AND rule-based logic.

This file deliberately contains TWO SEPARATE approaches so they are never
confused with each other:

A) PriorityModel  -> MACHINE LEARNING (scikit-learn)
   Features : TF-IDF of the task text  +  numeric features
              [days until deadline (log-scaled), urgency 1-5, importance 1-5]
   Model    : Logistic Regression (multi-class: High / Medium / Low)
   Data     : data/training/priority_training.csv (132 hand-labelled examples)

B) rule_based_priority() -> RULE-BASED SCORING (plain if/else, NO learning)
   Adds points for deadline proximity, urgency, importance and urgent
   keywords. Fully transparent: it returns the reasons for its decision.
"""
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.model_selection import StratifiedKFold, cross_val_score, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import FunctionTransformer, StandardScaler
from sklearn.tree import DecisionTreeClassifier

from config import PRIORITIES, PRIORITY_TRAINING_FILE
from models.text_utils import clean_text

RANDOM_STATE = 42
NO_DEADLINE_DAYS = 30.0     # a task without deadline is treated as "far away"
NUMERIC_COLS = ["days_left", "urgency", "importance"]

URGENT_WORDS = ["urgent", "asap", "immediately", "critical", "emergency",
                "deadline", "today", "tonight", "overdue", "must"]
RELAXED_WORDS = ["someday", "sometime", "later", "whenever", "when free", "eventually"]


def scale_days(X):
    """Log-scale the 'days_left' column: the difference between 0 and 2 days
    matters much more than the difference between 30 and 32 days.
    Overdue (negative) values are clipped to 0 = 'due now'."""
    X = np.asarray(X, dtype=float).copy()
    X[:, 0] = np.log1p(np.clip(X[:, 0], 0, 60))
    return X


def build_pipeline(classifier=None) -> Pipeline:
    features = ColumnTransformer([
        ("text", TfidfVectorizer(preprocessor=clean_text, ngram_range=(1, 2),
                                 sublinear_tf=True), "text"),
        ("num", Pipeline([("log_days", FunctionTransformer(scale_days)),
                          ("scale", StandardScaler())]), NUMERIC_COLS),
    ])
    return Pipeline([
        ("features", features),
        ("clf", classifier if classifier is not None else LogisticRegression(max_iter=3000, C=3.0)),
    ])


def load_training_data(path: str = PRIORITY_TRAINING_FILE) -> pd.DataFrame:
    df = pd.read_csv(path).dropna()
    return df[df["priority"].isin(PRIORITIES)].reset_index(drop=True)


def make_features(text: str, days_left, urgency: int, importance: int) -> pd.DataFrame:
    days = NO_DEADLINE_DAYS if days_left is None else float(days_left)
    return pd.DataFrame([{"text": text or "", "days_left": days,
                          "urgency": int(urgency), "importance": int(importance)}])


class PriorityModel:
    """A) Machine-learning priority classifier."""

    name = "TF-IDF + numeric features + Logistic Regression"

    def __init__(self, data_path: str = PRIORITY_TRAINING_FILE):
        self.data_path = data_path
        self.pipeline: Pipeline | None = None
        self.metrics: dict = {}
        self.n_training_samples = 0

    def evaluate(self, df: pd.DataFrame) -> dict:
        X, y = df[["text"] + NUMERIC_COLS], df["priority"]
        X_tr, X_te, y_tr, y_te = train_test_split(
            X, y, test_size=0.25, stratify=y, random_state=RANDOM_STATE)
        model = build_pipeline().fit(X_tr, y_tr)
        y_pred = model.predict(X_te)
        labels = PRIORITIES

        cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
        comparison = {}
        for label, clf in [
            ("Logistic Regression (used)", LogisticRegression(max_iter=3000, C=3.0)),
            ("Random Forest", RandomForestClassifier(n_estimators=200, random_state=RANDOM_STATE)),
            ("Decision Tree", DecisionTreeClassifier(random_state=RANDOM_STATE)),
        ]:
            scores = cross_val_score(build_pipeline(clf), X, y, cv=cv, scoring="accuracy")
            comparison[label] = {"mean": float(scores.mean()), "std": float(scores.std())}

        # How often does the rule-based method agree with the human labels?
        rule_preds = [rule_based_priority(r.text, r.days_left, r.urgency, r.importance)["label"]
                      for r in df.itertuples()]
        rule_acc = float(np.mean(np.array(rule_preds) == df["priority"].values))

        return {
            "test_accuracy": float(accuracy_score(y_te, y_pred)),
            "cv_mean": comparison["Logistic Regression (used)"]["mean"],
            "cv_std": comparison["Logistic Regression (used)"]["std"],
            "report": classification_report(y_te, y_pred, output_dict=True, zero_division=0),
            "confusion_matrix": confusion_matrix(y_te, y_pred, labels=labels).tolist(),
            "labels": labels,
            "comparison": comparison,
            "rule_based_accuracy_on_dataset": rule_acc,
            "train_size": int(len(X_tr)),
            "test_size": int(len(X_te)),
        }

    def train(self, evaluate: bool = True) -> "PriorityModel":
        df = load_training_data(self.data_path)
        if evaluate:
            self.metrics = self.evaluate(df)
        self.n_training_samples = len(df)
        self.pipeline = build_pipeline().fit(df[["text"] + NUMERIC_COLS], df["priority"])
        return self

    def predict(self, text: str, days_left, urgency: int = 3, importance: int = 3) -> dict:
        if self.pipeline is None:
            self.train()
        X = make_features(text, days_left, urgency, importance)
        probs = self.pipeline.predict_proba(X)[0]
        classes = self.pipeline.classes_
        order = np.argsort(probs)[::-1]
        return {
            "label": classes[order[0]],
            "confidence": float(probs[order[0]]),
            "probabilities": {classes[i]: float(probs[i]) for i in order},
        }


# ---------------------------------------------------------------------------
# B) RULE-BASED priority (no machine learning)
# ---------------------------------------------------------------------------
def rule_based_priority(text: str, days_left, urgency: int = 3, importance: int = 3) -> dict:
    """Score 0-100+ from simple, explainable rules.

    Deadline   : overdue +40 | <=1 day +35 | <=3 days +25 | <=7 days +15 | <=14 days +8
    Urgency    : (urgency - 1) x 7.5     (max 30)
    Importance : (importance - 1) x 7.5  (max 30)
    Keywords   : urgent words +10, relaxed words -10
    Result     : score >= 60 -> High, >= 30 -> Medium, otherwise Low
    """
    score, reasons = 0.0, []
    if days_left is None:
        reasons.append("No deadline set (+0)")
    elif days_left < 0:
        score += 40; reasons.append("Task is overdue (+40)")
    elif days_left <= 1:
        score += 35; reasons.append("Due within 1 day (+35)")
    elif days_left <= 3:
        score += 25; reasons.append("Due within 3 days (+25)")
    elif days_left <= 7:
        score += 15; reasons.append("Due within a week (+15)")
    elif days_left <= 14:
        score += 8; reasons.append("Due within 2 weeks (+8)")
    else:
        reasons.append("Deadline is far away (+0)")

    u_pts = (int(urgency) - 1) * 7.5
    i_pts = (int(importance) - 1) * 7.5
    score += u_pts + i_pts
    reasons.append(f"Urgency {urgency}/5 (+{u_pts:g})")
    reasons.append(f"Importance {importance}/5 (+{i_pts:g})")

    t = (text or "").lower()
    hit = next((w for w in URGENT_WORDS if w in t), None)
    if hit:
        score += 10; reasons.append(f"Urgent keyword '{hit}' (+10)")
    relaxed = next((w for w in RELAXED_WORDS if w in t), None)
    if relaxed:
        score -= 10; reasons.append(f"Relaxed keyword '{relaxed}' (-10)")

    label = "High" if score >= 60 else "Medium" if score >= 30 else "Low"
    return {"label": label, "score": round(score, 1), "reasons": reasons}
