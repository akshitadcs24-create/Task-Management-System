"""
models/category_model.py - MACHINE LEARNING task categorisation.

Algorithm
---------
1. Pre-processing : clean_text() lower-cases text and removes stop words.
2. Features       : TF-IDF (Term Frequency - Inverse Document Frequency) on
                    word unigrams + bigrams. Each task becomes a vector where
                    informative words ("meeting", "exam", "client") get high
                    weights and very common words get low weights.
3. Classifier     : Multinomial Logistic Regression. It learns one weight per
                    word per category and outputs a PROBABILITY for each
                    category, which we show to the user as "confidence".

Evaluation
----------
* Stratified 75/25 train-test split -> accuracy, precision, recall, F1,
  confusion matrix.
* 5-fold stratified cross-validation -> mean accuracy (more reliable on a
  small dataset than a single split).
* Comparison with Naive Bayes and Linear SVM.

Dataset: data/training/category_training.csv - 150 short task descriptions
(30 per category) written and labelled by hand for this project.
"""
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.model_selection import StratifiedKFold, cross_val_score, train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
from sklearn.svm import LinearSVC

from config import CATEGORIES, CATEGORY_MIN_CONFIDENCE, CATEGORY_TRAINING_FILE
from models.text_utils import clean_text

RANDOM_STATE = 42


def build_pipeline(classifier=None) -> Pipeline:
    return Pipeline([
        ("tfidf", TfidfVectorizer(preprocessor=clean_text, ngram_range=(1, 2),
                                  sublinear_tf=True, min_df=1)),
        ("clf", classifier if classifier is not None else LogisticRegression(max_iter=3000, C=10.0)),
    ])


def load_training_data(path: str = CATEGORY_TRAINING_FILE) -> pd.DataFrame:
    df = pd.read_csv(path)
    df = df.dropna(subset=["text", "category"])
    df = df[df["category"].isin(CATEGORIES)]
    return df.reset_index(drop=True)


class CategoryModel:
    """Trains, evaluates and serves the task category classifier."""

    name = "TF-IDF + Logistic Regression"

    def __init__(self, data_path: str = CATEGORY_TRAINING_FILE):
        self.data_path = data_path
        self.pipeline: Pipeline | None = None
        self.metrics: dict = {}
        self.n_training_samples = 0
        self.n_user_samples = 0

    # ------------------------------------------------------------------
    def evaluate(self, df: pd.DataFrame) -> dict:
        X, y = df["text"], df["category"]
        X_tr, X_te, y_tr, y_te = train_test_split(
            X, y, test_size=0.25, stratify=y, random_state=RANDOM_STATE)
        model = build_pipeline().fit(X_tr, y_tr)
        y_pred = model.predict(X_te)
        labels = sorted(y.unique())

        cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=RANDOM_STATE)
        comparison = {}
        for label, clf in [
            ("Logistic Regression (used)", LogisticRegression(max_iter=3000, C=10.0)),
            ("Multinomial Naive Bayes", MultinomialNB(alpha=0.3)),
            ("Linear SVM", LinearSVC()),
        ]:
            scores = cross_val_score(build_pipeline(clf), X, y, cv=cv, scoring="accuracy")
            comparison[label] = {"mean": float(scores.mean()), "std": float(scores.std())}

        return {
            "test_accuracy": float(accuracy_score(y_te, y_pred)),
            "cv_mean": comparison["Logistic Regression (used)"]["mean"],
            "cv_std": comparison["Logistic Regression (used)"]["std"],
            "report": classification_report(y_te, y_pred, output_dict=True, zero_division=0),
            "confusion_matrix": confusion_matrix(y_te, y_pred, labels=labels).tolist(),
            "labels": labels,
            "comparison": comparison,
            "train_size": int(len(X_tr)),
            "test_size": int(len(X_te)),
        }

    def train(self, extra_texts=None, extra_labels=None, evaluate: bool = True) -> "CategoryModel":
        """Train on the sample dataset (+ optional user-labelled tasks)."""
        df = load_training_data(self.data_path)
        if evaluate:
            self.metrics = self.evaluate(df)
        if extra_texts:
            extra = pd.DataFrame({"text": list(extra_texts), "category": list(extra_labels)})
            extra = extra[extra["category"].isin(CATEGORIES)]
            self.n_user_samples = len(extra)
            df = pd.concat([df, extra], ignore_index=True)
        self.n_training_samples = len(df)
        self.pipeline = build_pipeline().fit(df["text"], df["category"])
        return self

    # ------------------------------------------------------------------
    def predict(self, text: str) -> dict:
        """Return the suggested category, confidence and all probabilities."""
        if self.pipeline is None:
            self.train()
        if not clean_text(text):
            return {"label": "Other", "confidence": 0.0, "probabilities": {},
                    "low_confidence": True, "raw_label": None}
        probs = self.pipeline.predict_proba([text])[0]
        classes = self.pipeline.classes_
        order = np.argsort(probs)[::-1]
        probabilities = {classes[i]: float(probs[i]) for i in order}
        best = classes[order[0]]
        confidence = float(probs[order[0]])
        low = confidence < CATEGORY_MIN_CONFIDENCE
        return {
            "label": "Other" if low else best,
            "raw_label": best,
            "confidence": confidence,
            "probabilities": probabilities,
            "low_confidence": low,
        }

    def top_keywords(self, n: int = 8) -> dict:
        """Words with the highest learned weight for each category (explainability)."""
        if self.pipeline is None:
            self.train()
        vec = self.pipeline.named_steps["tfidf"]
        clf = self.pipeline.named_steps["clf"]
        vocab = np.array(vec.get_feature_names_out())
        return {cls: vocab[np.argsort(clf.coef_[i])[::-1][:n]].tolist()
                for i, cls in enumerate(clf.classes_)}
