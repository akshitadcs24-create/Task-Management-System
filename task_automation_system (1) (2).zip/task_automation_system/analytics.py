"""
analytics.py - Statistics, reports, charts (Plotly) and CSV export (Pandas).
"""
from datetime import datetime, timedelta

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

from config import CATEGORIES, PRIORITIES, STATUSES
from utils.helpers import now

# Blue & white brand palette + semantic colours
BRAND = "#1F5EFF"
NAVY = "#0F1E3D"
STATUS_COLORS = {"Completed": "#16A34A", "In Progress": "#1F5EFF",
                 "Pending": "#F59E0B", "Overdue": "#DC2626"}
PRIORITY_COLORS = {"High": "#DC2626", "Medium": "#F59E0B", "Low": "#16A34A"}
CATEGORY_COLORS = {"Work": "#1F5EFF", "Study": "#3B82F6", "Personal": "#60A5FA",
                   "Meetings": "#1E3A8A", "Other": "#93C5FD"}


# ---------------------------------------------------------------------------
# Statistics
# ---------------------------------------------------------------------------
def summary_stats(df: pd.DataFrame, reference: datetime | None = None) -> dict:
    ref = pd.Timestamp(reference or now())
    total = int(len(df))
    count = lambda s: int((df["status"] == s).sum()) if total else 0
    completed = count("Completed")
    open_mask = df["status"] != "Completed" if total else pd.Series(dtype=bool)
    due_today = due_week = 0
    on_time_rate = None
    if total:
        has_dl = df["deadline"].notna() & open_mask
        due_today = int((has_dl & (df["deadline"].dt.date == ref.date())).sum())
        due_week = int((has_dl & (df["deadline"] >= ref) &
                        (df["deadline"] <= ref + timedelta(days=7))).sum())
        done = df[(df["status"] == "Completed") & df["deadline"].notna() & df["completed_at"].notna()]
        if len(done):
            on_time_rate = round(float((done["completed_at"] <= done["deadline"]).mean() * 100), 1)
    return {
        "total": total,
        "completed": completed,
        "pending": count("Pending"),
        "in_progress": count("In Progress"),
        "overdue": count("Overdue"),
        "completion_rate": round(completed / total * 100, 1) if total else 0.0,
        "due_today": due_today,
        "due_this_week": due_week,
        "on_time_rate": on_time_rate,
        "high_priority_open": int((open_mask & (df["priority"] == "High")).sum()) if total else 0,
    }


def _counts(df: pd.DataFrame, column: str, order: list) -> pd.DataFrame:
    counts = df[column].value_counts().reindex(order, fill_value=0) if len(df) else \
        pd.Series(0, index=order)
    return counts.rename_axis(column).reset_index(name="tasks")


def status_distribution(df):
    return _counts(df, "status", STATUSES)


def priority_distribution(df):
    return _counts(df, "priority", PRIORITIES)


def category_distribution(df):
    return _counts(df, "category", CATEGORIES)


def productivity_series(df: pd.DataFrame, days: int = 30, reference: datetime | None = None) -> pd.DataFrame:
    """Tasks created vs completed per day for the last `days` days."""
    ref = pd.Timestamp(reference or now()).normalize()
    idx = pd.date_range(ref - timedelta(days=days - 1), ref, freq="D")
    created = df["created_at"].dropna().dt.normalize().value_counts() if len(df) else pd.Series(dtype=int)
    completed = df["completed_at"].dropna().dt.normalize().value_counts() if len(df) else pd.Series(dtype=int)
    out = pd.DataFrame({"date": idx,
                        "created": created.reindex(idx, fill_value=0).values,
                        "completed": completed.reindex(idx, fill_value=0).values})
    out["cumulative_completed"] = out["completed"].cumsum()
    return out


# ---------------------------------------------------------------------------
# Charts
# ---------------------------------------------------------------------------
def _style(fig: go.Figure, height: int = 320) -> go.Figure:
    fig.update_layout(height=height, margin=dict(l=10, r=10, t=40, b=10),
                      paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                      font=dict(family="Source Sans Pro, Segoe UI, sans-serif", color=NAVY, size=13),
                      title_font=dict(size=15, color=NAVY),
                      legend=dict(orientation="h", yanchor="bottom", y=-0.25, x=0))
    fig.update_xaxes(showgrid=False)
    fig.update_yaxes(gridcolor="#E6ECF8")
    return fig


def fig_status_donut(df):
    data = status_distribution(df)
    fig = px.pie(data, names="status", values="tasks", hole=0.62, title="Tasks by status",
                 color="status", color_discrete_map=STATUS_COLORS)
    fig.update_traces(textinfo="value", sort=False)
    return _style(fig)


def fig_priority_bar(df):
    data = priority_distribution(df)
    fig = px.bar(data, x="priority", y="tasks", title="Priority distribution", color="priority",
                 color_discrete_map=PRIORITY_COLORS, text="tasks")
    fig.update_layout(showlegend=False)
    return _style(fig)


def fig_category_pie(df):
    data = category_distribution(df)
    fig = px.pie(data, names="category", values="tasks", title="Category distribution",
                 color="category", color_discrete_map=CATEGORY_COLORS)
    fig.update_traces(textinfo="percent", textposition="inside", sort=False)
    return _style(fig)


def fig_priority_by_status(df):
    if len(df):
        data = df.groupby(["priority", "status"]).size().reset_index(name="tasks")
    else:
        data = pd.DataFrame({"priority": [], "status": [], "tasks": []})
    fig = px.bar(data, x="priority", y="tasks", color="status", title="Priority vs status",
                 category_orders={"priority": PRIORITIES, "status": STATUSES},
                 color_discrete_map=STATUS_COLORS, barmode="stack")
    return _style(fig)


def fig_productivity(df, days: int = 30):
    data = productivity_series(df, days)
    fig = go.Figure()
    fig.add_bar(x=data["date"], y=data["created"], name="Created", marker_color="#BFD3FF")
    fig.add_bar(x=data["date"], y=data["completed"], name="Completed", marker_color=BRAND)
    fig.add_scatter(x=data["date"], y=data["cumulative_completed"], name="Cumulative completed",
                    mode="lines", line=dict(color=NAVY, width=2), yaxis="y2")
    fig.update_layout(title=f"Productivity - last {days} days", barmode="group",
                      yaxis=dict(rangemode="tozero"),
                      yaxis2=dict(overlaying="y", side="right", showgrid=False, title=None,
                                  rangemode="tozero", tickformat=",.0f"))
    fig = _style(fig, 340)
    fig.update_layout(margin=dict(l=10, r=40, t=40, b=10))
    return fig


def fig_completion_gauge(rate: float):
    fig = go.Figure(go.Indicator(
        mode="gauge+number", value=rate, number={"suffix": "%", "font": {"size": 36, "color": NAVY}},
        gauge={"axis": {"range": [0, 100]}, "bar": {"color": BRAND},
               "bgcolor": "#EEF3FF", "borderwidth": 0}))
    fig = _style(fig, 340)
    fig.update_layout(title="Completion rate", margin=dict(l=45, r=45, t=60, b=10))
    return fig


def fig_confusion_matrix(matrix, labels, title):
    fig = px.imshow(matrix, x=labels, y=labels, text_auto=True, color_continuous_scale="Blues",
                    labels=dict(x="Predicted", y="Actual", color="Count"), title=title)
    return _style(fig, 360)


def fig_probabilities(probabilities: dict, title: str):
    data = pd.DataFrame({"label": list(probabilities), "probability": list(probabilities.values())})
    fig = px.bar(data, x="probability", y="label", orientation="h", title=title, text_auto=".0%",
                 range_x=[0, 1], color_discrete_sequence=[BRAND])
    fig.update_yaxes(categoryorder="total ascending", title=None)
    return _style(fig, 260)


# ---------------------------------------------------------------------------
# Reports & CSV export
# ---------------------------------------------------------------------------
EXPORT_COLUMNS = {"id": "Task ID", "title": "Title", "description": "Description",
                  "category": "Category", "priority": "Priority", "status": "Status",
                  "deadline": "Deadline", "created_at": "Created", "updated_at": "Updated",
                  "completed_at": "Completed At", "ai_category": "AI Category",
                  "ai_priority": "AI Priority"}


def export_frame(df: pd.DataFrame) -> pd.DataFrame:
    out = df[[c for c in EXPORT_COLUMNS if c in df.columns]].rename(columns=EXPORT_COLUMNS)
    for col in ("Deadline", "Created", "Updated", "Completed At"):
        if col in out.columns:
            out[col] = pd.to_datetime(out[col]).dt.strftime("%Y-%m-%d %H:%M").fillna("")
    return out


def completion_report(df: pd.DataFrame) -> pd.DataFrame:
    done = df[df["status"] == "Completed"].copy()
    out = export_frame(done)
    if len(done):
        on_time = (done["deadline"].isna()) | (done["completed_at"] <= done["deadline"])
        out["On Time"] = on_time.map({True: "Yes", False: "No"}).values
    else:
        out["On Time"] = pd.Series(dtype=str)
    return out


def pending_report(df: pd.DataFrame, reference: datetime | None = None) -> pd.DataFrame:
    from automation import organize_tasks  # local import avoids circular import
    open_df = organize_tasks(df[df["status"] != "Completed"], reference)
    out = export_frame(open_df)
    if len(open_df):
        out["Smart Score"] = open_df["smart_score"].values
    return out


def group_report(df: pd.DataFrame, column: str, order: list) -> pd.DataFrame:
    """Counts per group (priority or category) split by status."""
    if len(df):
        table = pd.crosstab(df[column], df["status"]).reindex(index=order, columns=STATUSES,
                                                               fill_value=0)
    else:
        table = pd.DataFrame(0, index=order, columns=STATUSES)
    table["Total"] = table.sum(axis=1)
    totals = table["Total"].astype(float)
    completed = table["Completed"].astype(float)
    table["Completion %"] = (completed / totals.where(totals > 0) * 100).fillna(0.0).round(1)
    return table.rename_axis(column.title()).reset_index()


def to_csv_bytes(df: pd.DataFrame) -> bytes:
    return df.to_csv(index=False).encode("utf-8")
