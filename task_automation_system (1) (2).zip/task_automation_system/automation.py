"""
automation.py - Workflow automation engine (RULE-BASED, runs automatically).

run_automation() is executed every time a logged-in user loads a page,
and can also be triggered manually from the Automation Center. It:

 1. Marks open tasks whose deadline has passed as "Overdue".
 2. Restores "Overdue" tasks to "Pending" if their deadline was extended.
 3. (Optional) Escalates priority: Low -> Medium when due within 24 h,
    and any overdue task -> High.
 4. Creates in-app notifications for tasks due within 24 h and 72 h.
 5. Fires task reminders when their reminder time has been reached.
 6. Logs every automatic action in the automation_log table.

Notifications use a unique "dedupe_key", so the same alert is never
created twice even though the automation runs on every page load.
"""
from datetime import datetime, timedelta

import pandas as pd

import database as db
from config import DUE_SOON_HOURS, PRIORITY_WEIGHT, UPCOMING_HOURS
from utils.helpers import format_dt, now, now_str, parse_dt, time_left_text, to_str

STATUS_ORDER = {"Overdue": 0, "In Progress": 1, "Pending": 2, "Completed": 3}


def _log(user_id: int, task_id, action: str, details: str = "") -> None:
    db.execute("INSERT INTO automation_log (user_id, task_id, action, details, created_at) "
               "VALUES (?, ?, ?, ?, ?)", (user_id, task_id, action, details, now_str()))


def _notify(user_id: int, task_id, ntype: str, message: str, dedupe_key: str) -> bool:
    """Insert a notification unless one with the same dedupe_key already exists."""
    with db.db_cursor() as cur:
        cur.execute("INSERT OR IGNORE INTO notifications (user_id, task_id, type, message, "
                    "dedupe_key, created_at) VALUES (?, ?, ?, ?, ?, ?)",
                    (user_id, task_id, ntype, message, dedupe_key, now_str()))
        return cur.rowcount > 0


def run_automation(user_id: int, reference: datetime | None = None, escalate: bool | None = None) -> dict:
    """Run all automatic workflow rules for one user. Returns a summary."""
    ref = reference or now()
    ref_s = to_str(ref)
    if escalate is None:
        user = db.fetch_one("SELECT auto_escalate FROM users WHERE id = ?", (user_id,))
        escalate = bool(user and user["auto_escalate"])

    summary = {"overdue_marked": 0, "restored": 0, "escalated": 0,
               "due_soon_alerts": 0, "reminders": 0, "checked": 0}
    tasks = db.fetch_all("SELECT id, title, status, priority, deadline, reminder_at "
                         "FROM tasks WHERE user_id = ? AND status != 'Completed'", (user_id,))
    summary["checked"] = len(tasks)

    for t in tasks:
        deadline = parse_dt(t["deadline"])
        # --- Rule 1: detect overdue tasks -------------------------------------
        if deadline and deadline < ref and t["status"] in ("Pending", "In Progress"):
            db.execute("UPDATE tasks SET status = 'Overdue', updated_at = ? WHERE id = ?",
                       (ref_s, t["id"]))
            _log(user_id, t["id"], "Marked overdue",
                 f"'{t['title']}' passed its deadline ({format_dt(deadline)}); "
                 f"status {t['status']} -> Overdue")
            _notify(user_id, t["id"], "overdue",
                    f"'{t['title']}' is overdue (deadline was {format_dt(deadline)}).",
                    f"overdue:{t['id']}:{t['deadline']}")
            t["status"] = "Overdue"
            summary["overdue_marked"] += 1

        # --- Rule 2: deadline extended -> back to Pending ----------------------
        elif t["status"] == "Overdue" and (deadline is None or deadline >= ref):
            db.execute("UPDATE tasks SET status = 'Pending', updated_at = ? WHERE id = ?",
                       (ref_s, t["id"]))
            _log(user_id, t["id"], "Restored to Pending",
                 f"'{t['title']}' has a new deadline ({format_dt(deadline)}); status Overdue -> Pending")
            t["status"] = "Pending"
            summary["restored"] += 1

        hours_left = (deadline - ref).total_seconds() / 3600 if deadline else None

        # --- Rule 3: priority escalation (optional) ---------------------------
        if escalate and hours_left is not None:
            new_priority = None
            if t["status"] == "Overdue" and t["priority"] != "High":
                new_priority = "High"
            elif 0 <= hours_left <= DUE_SOON_HOURS and t["priority"] == "Low":
                new_priority = "Medium"
            if new_priority:
                db.execute("UPDATE tasks SET priority = ?, updated_at = ? WHERE id = ?",
                           (new_priority, ref_s, t["id"]))
                _log(user_id, t["id"], "Priority escalated",
                     f"'{t['title']}' {t['priority']} -> {new_priority} (deadline approaching/passed)")
                summary["escalated"] += 1

        # --- Rule 4: approaching deadline alerts ------------------------------
        if hours_left is not None and 0 <= hours_left <= UPCOMING_HOURS:
            window = "24h" if hours_left <= DUE_SOON_HOURS else "72h"
            label = "within 24 hours" if window == "24h" else "within 3 days"
            created = _notify(user_id, t["id"], f"due_{window}",
                              f"'{t['title']}' is due {label} ({time_left_text(deadline, ref)}, "
                              f"{format_dt(deadline)}).",
                              f"due_{window}:{t['id']}:{t['deadline']}")
            summary["due_soon_alerts"] += int(created)

        # --- Rule 5: reminders -------------------------------------------------
        reminder = parse_dt(t["reminder_at"])
        if reminder and reminder <= ref:
            created = _notify(user_id, t["id"], "reminder",
                              f"Reminder: '{t['title']}' "
                              f"({'due ' + time_left_text(deadline, ref) if deadline else 'no deadline'}).",
                              f"reminder:{t['id']}:{t['reminder_at']}")
            if created:
                _log(user_id, t["id"], "Reminder sent", f"Reminder for '{t['title']}'")
            summary["reminders"] += int(created)

    if any(summary[k] for k in ("overdue_marked", "restored", "escalated")):
        _log(user_id, None, "Automation run",
             f"{summary['overdue_marked']} overdue, {summary['restored']} restored, "
             f"{summary['escalated']} escalated")
    return summary


# ---------------------------------------------------------------------------
# Automatic organisation (smart ordering)
# ---------------------------------------------------------------------------
def smart_score(row, reference: datetime | None = None) -> float:
    """Higher score = should be done sooner.
    score = priority weight x 30 + deadline pressure (0-50) + status bonus."""
    ref = reference or now()
    if row["status"] == "Completed":
        return -1.0
    score = PRIORITY_WEIGHT.get(row["priority"], 1) * 30
    deadline = row["deadline"]
    if deadline is not None and not pd.isna(deadline):
        hours = (pd.Timestamp(deadline).to_pydatetime() - ref).total_seconds() / 3600
        if hours < 0:
            score += 50
        else:
            score += max(0.0, 50 - hours / 24 * 5)  # loses 5 points per day of slack
    if row["status"] == "In Progress":
        score += 5
    return round(score, 1)


def organize_tasks(df: pd.DataFrame, reference: datetime | None = None) -> pd.DataFrame:
    """Return the tasks sorted automatically by urgency (smart score)."""
    if df.empty:
        return df.assign(smart_score=pd.Series(dtype=float))
    df = df.copy()
    df["smart_score"] = df.apply(lambda r: smart_score(r, reference), axis=1)
    df["_status_rank"] = df["status"].map(STATUS_ORDER).fillna(9)
    df = df.sort_values(["smart_score", "_status_rank"], ascending=[False, True])
    return df.drop(columns="_status_rank").reset_index(drop=True)


# ---------------------------------------------------------------------------
# Notifications & log
# ---------------------------------------------------------------------------
def get_notifications(user_id: int, unread_only: bool = False, limit: int = 50) -> list[dict]:
    q = "SELECT * FROM notifications WHERE user_id = ?"
    if unread_only:
        q += " AND is_read = 0"
    q += " ORDER BY created_at DESC, id DESC LIMIT ?"
    return db.fetch_all(q, (user_id, limit))


def unread_count(user_id: int) -> int:
    row = db.fetch_one("SELECT COUNT(*) AS n FROM notifications WHERE user_id = ? AND is_read = 0",
                       (user_id,))
    return row["n"] if row else 0


def mark_notification_read(user_id: int, notification_id: int) -> None:
    db.execute("UPDATE notifications SET is_read = 1 WHERE user_id = ? AND id = ?",
               (user_id, notification_id))


def mark_all_read(user_id: int) -> int:
    return db.execute("UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0",
                      (user_id,))


def get_automation_log(user_id: int, limit: int = 100) -> list[dict]:
    return db.fetch_all("SELECT created_at, action, details FROM automation_log "
                        "WHERE user_id = ? ORDER BY id DESC LIMIT ?", (user_id, limit))


def upcoming_tasks(df: pd.DataFrame, hours: int = UPCOMING_HOURS, reference: datetime | None = None) -> pd.DataFrame:
    """Open tasks due within the next `hours` hours."""
    ref = pd.Timestamp(reference or now())
    if df.empty:
        return df
    mask = (df["status"] != "Completed") & df["deadline"].notna() & \
           (df["deadline"] >= ref) & (df["deadline"] <= ref + timedelta(hours=hours))
    return df[mask].sort_values("deadline")
