"""
auth.py - User registration, login and password security.

Passwords are NEVER stored in plain text. We use PBKDF2-HMAC-SHA256
(from Python's standard library) with:
  * a random 16-byte salt per user (so identical passwords give different hashes)
  * 200,000 iterations (slows down brute-force attacks)
Verification uses hmac.compare_digest (constant-time comparison).
"""
import hashlib
import hmac
import re
import secrets

import database as db
from utils.helpers import now_str

PBKDF2_ITERATIONS = 200_000
USERNAME_RE = re.compile(r"^[A-Za-z0-9_.]{3,30}$")
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def hash_password(password: str, salt_hex: str | None = None) -> tuple[str, str]:
    """Return (hash_hex, salt_hex). A new salt is generated if none is given."""
    if salt_hex is None:
        salt_hex = secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac(
        "sha256", password.encode("utf-8"), bytes.fromhex(salt_hex), PBKDF2_ITERATIONS
    )
    return digest.hex(), salt_hex


def verify_password(password: str, stored_hash: str, salt_hex: str) -> bool:
    candidate, _ = hash_password(password, salt_hex)
    return hmac.compare_digest(candidate, stored_hash)


def validate_registration(username: str, password: str, confirm: str, email: str) -> str | None:
    """Return an error message, or None if the input is valid."""
    if not USERNAME_RE.match(username or ""):
        return "Username must be 3-30 characters: letters, numbers, '_' or '.'."
    if len(password or "") < 6:
        return "Password must be at least 6 characters long."
    if not re.search(r"[A-Za-z]", password) or not re.search(r"\d", password):
        return "Password must contain at least one letter and one number."
    if password != confirm:
        return "Passwords do not match."
    if email and not EMAIL_RE.match(email):
        return "Please enter a valid email address."
    return None


def register_user(username: str, password: str, confirm: str,
                  full_name: str = "", email: str = "") -> tuple[bool, str]:
    """Create a new account. Returns (success, message)."""
    username = (username or "").strip()
    email = (email or "").strip()
    error = validate_registration(username, password, confirm, email)
    if error:
        return False, error
    if db.fetch_one("SELECT id FROM users WHERE username = ?", (username,)):
        return False, "That username is already taken."
    pw_hash, salt = hash_password(password)
    db.execute(
        "INSERT INTO users (username, full_name, email, password_hash, salt, created_at) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (username, (full_name or "").strip(), email, pw_hash, salt, now_str()),
    )
    return True, "Account created successfully. You can now log in."


def authenticate(username: str, password: str) -> dict | None:
    """Return the user (without password fields) if the credentials are correct."""
    user = db.fetch_one("SELECT * FROM users WHERE username = ?", ((username or "").strip(),))
    if not user or not verify_password(password or "", user["password_hash"], user["salt"]):
        return None
    return public_user(user)


def get_user(user_id: int) -> dict | None:
    user = db.fetch_one("SELECT * FROM users WHERE id = ?", (user_id,))
    return public_user(user) if user else None


def public_user(user: dict) -> dict:
    """Strip secret fields before the user dict is kept in the session."""
    return {k: v for k, v in user.items() if k not in ("password_hash", "salt")}


def set_auto_escalate(user_id: int, enabled: bool) -> None:
    db.execute("UPDATE users SET auto_escalate = ? WHERE id = ?", (1 if enabled else 0, user_id))
