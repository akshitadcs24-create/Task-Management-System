#!/usr/bin/env bash
# macOS / Linux helper: creates a virtual environment (first run only), installs packages and starts the app.
set -e
cd "$(dirname "$0")"
[ -d venv ] || python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
