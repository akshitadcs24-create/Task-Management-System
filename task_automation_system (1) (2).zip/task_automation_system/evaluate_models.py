"""
evaluate_models.py - Print the evaluation of both ML models in the terminal.

Usage:  python evaluate_models.py
"""
import pandas as pd

from models.category_model import CategoryModel
from models.priority_model import PriorityModel


def show(title: str, metrics: dict) -> None:
    print("=" * 70)
    print(title)
    print("=" * 70)
    print(f"Train / test split     : {metrics['train_size']} / {metrics['test_size']}")
    print(f"Hold-out test accuracy : {metrics['test_accuracy']:.1%}")
    print(f"5-fold CV accuracy     : {metrics['cv_mean']:.1%} (+/- {metrics['cv_std']:.1%})")
    if "rule_based_accuracy_on_dataset" in metrics:
        print(f"Rule-based agreement   : {metrics['rule_based_accuracy_on_dataset']:.1%} (on the full dataset)")
    print("\nAlgorithm comparison (5-fold CV):")
    for name, v in metrics["comparison"].items():
        print(f"  {name:<32} {v['mean']:.1%} (+/- {v['std']:.1%})")
    report = pd.DataFrame({k: v for k, v in metrics["report"].items() if isinstance(v, dict)}).T
    print("\nClassification report (hold-out test set):")
    print(report.round(2).to_string())
    print("\nConfusion matrix (rows = actual, columns = predicted):")
    print(pd.DataFrame(metrics["confusion_matrix"], index=metrics["labels"], columns=metrics["labels"]).to_string())
    print()


if __name__ == "__main__":
    cat = CategoryModel().train()
    show("CATEGORY MODEL - TF-IDF + Logistic Regression", cat.metrics)
    print("Top words per category:")
    for c, words in cat.top_keywords(6).items():
        print(f"  {c:<9}: {', '.join(words)}")
    print()
    pri = PriorityModel().train()
    show("PRIORITY MODEL - TF-IDF + numeric features + Logistic Regression", pri.metrics)
