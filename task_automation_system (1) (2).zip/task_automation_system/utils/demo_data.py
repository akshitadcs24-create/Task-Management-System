"""
utils/demo_data.py - Loads a realistic set of sample tasks for demonstrations.

Category and priority for each demo task are produced by the same AI engine
the user sees, so the demo also exercises the ML models.
"""
from datetime import timedelta

import task_manager as tm
from utils.helpers import now

# (title, description, days offset for deadline (None = no deadline), status, urgency, importance,
#  days ago created, days ago completed)
DEMO_TASKS = [
    ("Prepare quarterly sales report", "Compile Q3 numbers for the management team", 2, "In Progress", 4, 5, 6, None),
    ("Fix login bug reported by client", "Users cannot log in on mobile, urgent fix needed", 0.3, "Pending", 5, 5, 1, None),
    ("Weekly team meeting", "Attend the weekly sync call with developers at 10 am", 1, "Pending", 3, 3, 2, None),
    ("Revise data structures for exam", "Trees, graphs and hashing chapters", 4, "Pending", 3, 5, 3, None),
    ("Pay electricity bill", "Pay online before the due date", -1, "Pending", 4, 4, 8, None),
    ("Complete statistics assignment", "Hypothesis testing problems 1-10", -2, "In Progress", 4, 4, 10, None),
    ("Buy groceries for the week", "Vegetables, fruits, milk", 3, "Pending", 2, 2, 1, None),
    ("Client demo meeting", "Show the new dashboard feature to the client", 6, "Pending", 3, 5, 4, None),
    ("Read research paper on transformers", "Attention is all you need", 12, "Pending", 2, 3, 5, None),
    ("Organise the bookshelf", "Someday when free", None, "Pending", 1, 1, 9, None),
    ("Deploy website to production", "Release version 2.0", -3, "Completed", 4, 5, 14, 4),
    ("Write unit tests for API", "Cover the task endpoints", -6, "Completed", 3, 4, 20, 7),
    ("Sprint planning session", "Plan next sprint with the team", -8, "Completed", 3, 4, 18, 8),
    ("Finish Python pandas course module", "Complete module 4 quizzes", -10, "Completed", 2, 4, 25, 9),
    ("Book doctor appointment", "Annual health checkup", -5, "Completed", 3, 4, 12, 3),
    ("Call mom on the weekend", "", -12, "Completed", 2, 3, 15, 13),
    ("Update project documentation", "Add setup steps to the README", -1, "Completed", 3, 3, 9, 2),
    ("Practice coding problems", "Arrays and strings on LeetCode", -4, "Completed", 2, 4, 11, 5),
    ("Look for a good podcast", "", 20, "Pending", 1, 1, 2, None),
    ("One on one with mentor", "Discuss internship progress and feedback", 2.5, "Pending", 3, 4, 3, None),
]


def load_demo_tasks(user_id: int, engine) -> int:
    """Insert the demo tasks for this user and back-date their timestamps."""
    import database as db
    from utils.helpers import to_str

    base = now()
    created = 0
    for title, desc, dl, status, urg, imp, created_ago, completed_ago in DEMO_TASKS:
        deadline = base + timedelta(days=dl) if dl is not None else None
        cat = engine.suggest_category(title, desc)
        pri = engine.suggest_priority(title, desc, deadline, urg, imp)
        task_id = tm.create_task(user_id, title, desc, cat["label"], pri["final"], deadline,
                                 status, urg, imp, ai_category=cat["label"], ai_priority=pri["final"])
        created_at = to_str(base - timedelta(days=created_ago))
        completed_at = to_str(base - timedelta(days=completed_ago)) if completed_ago is not None else None
        db.execute("UPDATE tasks SET created_at = ?, updated_at = ?, completed_at = ? WHERE id = ?",
                   (created_at, completed_at or created_at, completed_at, task_id))
        created += 1
    return created
