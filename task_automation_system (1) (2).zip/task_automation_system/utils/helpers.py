"""
utils/helpers.py - Small reusable helper functions.

Contains date/time helpers and a RULE-BASED (not machine learning)
deadline detector that finds phrases such as "tomorrow", "in 3 days",
"by Friday" or "2026-12-05" inside a task description.
"""
import re
from datetime import datetime, timedelta

import pandas as pd

from config import DATETIME_FMT

DEFAULT_DEADLINE_HOUR = 18  # used when a date is found but no time is given

WEEKDAYS = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
MONTHS = {
    "jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6,
    "jul": 7, "aug": 8, "sep": 9, "oct": 10, "nov": 11, "dec": 12,
}


# ---------------------------------------------------------------------------
# Date / time helpers
# ---------------------------------------------------------------------------
def now() -> datetime:
    """Current local time without microseconds."""
    return datetime.now().replace(microsecond=0)


def now_str() -> str:
    return now().strftime(DATETIME_FMT)


def to_str(value: datetime | None) -> str | None:
    return value.strftime(DATETIME_FMT) if value else None


def parse_dt(value) -> datetime | None:
    """Parse a stored datetime string (or pass through a datetime)."""
    if value is None or value is pd.NaT or (isinstance(value, float) and value != value) or value == "":
        return None                                # empty values (incl. NaN / NaT from DataFrames)
    if isinstance(value, pd.Timestamp):
        return value.to_pydatetime()
    if isinstance(value, datetime):
        return value
    for fmt in (DATETIME_FMT, "%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            return datetime.strptime(str(value), fmt)
        except ValueError:
            continue
    return None


def hours_until(deadline, reference: datetime | None = None) -> float | None:
    """Hours from reference (default: now) until the deadline. Negative = overdue."""
    deadline = parse_dt(deadline)
    if deadline is None:
        return None
    reference = reference or now()
    return (deadline - reference).total_seconds() / 3600.0


def days_until(deadline, reference: datetime | None = None) -> float | None:
    h = hours_until(deadline, reference)
    return None if h is None else h / 24.0


def time_left_text(deadline, reference: datetime | None = None) -> str:
    """Human friendly text such as 'in 2 days' or '5 hours overdue'."""
    h = hours_until(deadline, reference)
    if h is None:
        return "No deadline"
    overdue = h < 0
    h = abs(h)
    if h < 1:
        amount = f"{max(int(h * 60), 1)} min"
    elif h < 48:
        amount = f"{int(h)} hour{'s' if int(h) != 1 else ''}"
    else:
        d = int(h // 24)
        amount = f"{d} day{'s' if d != 1 else ''}"
    return f"{amount} overdue" if overdue else f"in {amount}"


def format_dt(value) -> str:
    dt = parse_dt(value)
    return dt.strftime("%d %b %Y, %I:%M %p") if dt else "—"


# ---------------------------------------------------------------------------
# Rule-based deadline detection (regular expressions, NOT machine learning)
# ---------------------------------------------------------------------------
def _extract_time(text: str):
    """Find a time like '5pm', '5:30 pm', 'at 17:30'. Returns (hour, minute) or None."""
    m = re.search(r"\b(\d{1,2})(?::(\d{2}))?\s*(am|pm)\b", text)
    if m:
        hour, minute = int(m.group(1)), int(m.group(2) or 0)
        if 1 <= hour <= 12 and 0 <= minute < 60:
            if m.group(3) == "pm" and hour != 12:
                hour += 12
            if m.group(3) == "am" and hour == 12:
                hour = 0
            return hour, minute
    m = re.search(r"\bat\s+(\d{1,2}):(\d{2})\b", text)
    if m:
        hour, minute = int(m.group(1)), int(m.group(2))
        if hour < 24 and minute < 60:
            return hour, minute
    if "noon" in text:
        return 12, 0
    if "tonight" in text:
        return 21, 0
    return None


def _with_time(day: datetime, time_tuple) -> datetime:
    hour, minute = time_tuple if time_tuple else (DEFAULT_DEADLINE_HOUR, 0)
    return day.replace(hour=hour, minute=minute, second=0, microsecond=0)


def detect_deadline_from_text(text: str, reference: datetime | None = None) -> dict | None:
    """Look for a deadline phrase inside free text.

    Returns {"deadline": datetime, "matched": "<phrase>"} or None.
    This is a transparent rule-based parser built with regular expressions.
    """
    if not text:
        return None
    reference = reference or now()
    t = text.lower()
    tm = _extract_time(t)
    today = reference.replace(hour=0, minute=0, second=0, microsecond=0)

    # 1) Relative amounts: "in 3 days", "within 2 hours", "in 1 week"
    m = re.search(r"\b(?:in|within)\s+(\d{1,3})\s+(hour|hours|hr|hrs|day|days|week|weeks)\b", t)
    if m:
        n, unit = int(m.group(1)), m.group(2)
        if unit.startswith("h"):
            return {"deadline": reference + timedelta(hours=n), "matched": m.group(0)}
        days = n * 7 if unit.startswith("week") else n
        return {"deadline": _with_time(today + timedelta(days=days), tm), "matched": m.group(0)}

    # 2) Explicit ISO date: 2026-12-05
    m = re.search(r"\b(\d{4})-(\d{1,2})-(\d{1,2})\b", t)
    if m:
        try:
            d = datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)))
            return {"deadline": _with_time(d, tm), "matched": m.group(0)}
        except ValueError:
            pass

    # 3) Day-first numeric date (common in India/UK): 05/12/2026 or 05-12-2026
    m = re.search(r"\b(\d{1,2})[/-](\d{1,2})[/-](\d{4})\b", t)
    if m:
        try:
            d = datetime(int(m.group(3)), int(m.group(2)), int(m.group(1)))
            return {"deadline": _with_time(d, tm), "matched": m.group(0)}
        except ValueError:
            pass

    # 4) Month names: "20 nov", "nov 20", "20th november"
    m = (re.search(r"\b(\d{1,2})(?:st|nd|rd|th)?\s+(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\b", t)
         or re.search(r"\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\s+(\d{1,2})(?:st|nd|rd|th)?\b", t))
    if m:
        a, b = m.group(1), m.group(2)
        day, mon = (int(a), MONTHS[b]) if a.isdigit() else (int(b), MONTHS[a])
        try:
            d = datetime(reference.year, mon, day)
            if d < today:  # date already passed this year -> next year
                d = datetime(reference.year + 1, mon, day)
            return {"deadline": _with_time(d, tm), "matched": m.group(0)}
        except ValueError:
            pass

    # 5) Keywords
    if "day after tomorrow" in t:
        return {"deadline": _with_time(today + timedelta(days=2), tm), "matched": "day after tomorrow"}
    if re.search(r"\btomorrow\b", t):
        return {"deadline": _with_time(today + timedelta(days=1), tm), "matched": "tomorrow"}
    if re.search(r"\b(today|tonight|eod|end of day)\b", t):
        word = re.search(r"\b(today|tonight|eod|end of day)\b", t).group(1)
        return {"deadline": _with_time(today, tm), "matched": word}
    if "next week" in t:
        return {"deadline": _with_time(today + timedelta(days=7), tm), "matched": "next week"}
    if "end of the month" in t or "end of month" in t:
        nxt = (today.replace(day=28) + timedelta(days=4)).replace(day=1)
        return {"deadline": _with_time(nxt - timedelta(days=1), tm), "matched": "end of month"}

    # 6) Weekdays: "by friday", "on monday", "next tuesday"
    m = re.search(r"\b(next\s+)?(monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b", t)
    if m:
        target = WEEKDAYS.index(m.group(2))
        ahead = (target - reference.weekday()) % 7
        if ahead == 0:
            ahead = 7 if m.group(1) else 0
        return {"deadline": _with_time(today + timedelta(days=ahead), tm), "matched": m.group(0)}

    return None
