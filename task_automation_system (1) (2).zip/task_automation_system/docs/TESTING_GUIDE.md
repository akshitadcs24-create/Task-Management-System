# Testing Guide — Feature by Feature

## Part A — Automated tests (2 minutes)
```bash
python -m pytest -v
```
Expected: **57 passed** (shows every test name). Last run on the delivered code: 57 passed.

To see the ML evaluation numbers:
```bash
python evaluate_models.py
```
Expected: category 5-fold CV ≈ 69 %, hold-out ≈ 82 %; priority 5-fold CV ≈ 98 %, rule-based agreement ≈ 89 %.

---

## Part B — Manual demo script (use this during your presentation)

Start the app with `streamlit run app.py`. Tick each step.

### 1. Registration & login
| # | Action | Expected result |
|---|---|---|
| 1.1 | *Create account* tab → username `ab`, password `secret123` twice | Error: username must be 3–30 characters |
| 1.2 | username `demo`, password `abcdef` | Error: must contain a letter and a number |
| 1.3 | username `demo`, password `demo1234`, confirm `demo1234` | "Account created successfully" |
| 1.4 | Register `demo` again | "That username is already taken" |
| 1.5 | *Log in* with wrong password | "Invalid username or password" |
| 1.6 | Log in with `demo` / `demo1234` | Dashboard opens, sidebar shows your name |

### 2. Dashboard
| 2.1 | Empty dashboard → **Load demo tasks** | "20 demo tasks loaded", cards and charts filled |
| 2.2 | Check cards | Total 20, overdue 2 (electricity bill, statistics assignment), completion 40 % |
| 2.3 | Hover a chart | Interactive tooltip |

### 3. Task management
| 3.1 | *Create Task* → title `Revise chapter 4 for the semester exam` | AI box: category **Study** |
| 3.2 | Add description `submit by Friday at 5pm` | "Deadline detected: … Friday 05:00 PM" → click **Use detected deadline** → date/time fields update |
| 3.3 | Set Urgency 5, Importance 5 | Both priority methods show **High** |
| 3.4 | Choose reminder "1 day before" → **Create task** | Success message; task appears in My Tasks |
| 3.5 | *My Tasks* → change status dropdown to *In Progress* | "Status updated" |
| 3.6 | **Edit task** → change title & priority → Save | "Task updated", new values shown |
| 3.7 | Trash icon → **Yes, delete** | Task removed |
| 3.8 | Search `bill`, filter Status = Overdue, sort by Priority | List updates instantly |

### 4. AI categorisation (ML)
| 4.1 | *AI Insights → Try the AI* → type `Zoom call with the HR team` | Meetings |
| 4.2 | `Pay the water bill` | Personal |
| 4.3 | `Fix the production server crash` | Work |
| 4.4 | *Category model* tab | Accuracy, CV, comparison table, confusion matrix, top words |
| 4.5 | **Retrain with my tasks** | "Personal model trained on N examples" |

### 5. Priority prediction (ML vs rules)
| 5.1 | Try text `Organise photos someday`, days 40, urgency 1, importance 1 | ML Low, Rule Low |
| 5.2 | Text `Submit report urgent`, days 0.5, urgency 5, importance 5 | ML High, Rule High |
| 5.3 | *Priority models* tab | ML metrics + rule table clearly labelled "no machine learning" |

### 6. Deadline detection & workflow automation
| 6.1 | Create a task with deadline **today, 2 minutes from now** | Status Pending |
| 6.2 | Wait 2–3 minutes, click **Run automation now** | Task becomes **Overdue**, notification + log entry, priority escalated to High |
| 6.3 | Edit that task, move deadline to next week | Automatically back to **Pending** ("Restored to Pending" in log) |
| 6.4 | Create a task due in 5 hours | "Due within 24 hours" notification appears once (click Run again → no duplicate) |
| 6.5 | Toggle *Auto-escalate* off, create Low task due in 3 h | Priority stays Low |
| 6.6 | *Smart task queue* tab | Overdue / high-priority / closest deadlines on top |
| 6.7 | **Mark all as read** | Unread counter in sidebar disappears |

### 7. Reports & CSV export
| 7.1 | *Reports* → each tab | Completion, Pending, Priority-wise, Category-wise, Productivity |
| 7.2 | **Download all tasks (CSV)** → open in Excel | All tasks with readable column names |
| 7.3 | Change period to *Last 7 days* | Numbers and tables change |

### 8. Persistence
| 8.1 | Stop the app (Ctrl + C) and start again; log in | All tasks are still there |
| 8.2 | Register a second user | Sees none of the first user's tasks |
| 8.3 | Log out | Back to login screen |

---

## Part C — Results recorded during development
* Automated: 57/57 tests passed.
* Browser walkthrough (Chromium, 1440×900): login, registration, demo data, dashboard, task list, edit form, create task
  with AI suggestions and detected deadline, AI Insights (3 tabs), Automation Center (3 tabs), Reports (3 tabs) and CSV
  download — no page errors. Screenshots: `docs/screenshots/`.
* Bugs found by testing and fixed: (1) category report crashed when a group had 0 tasks; (2) tasks without a deadline
  crashed the smart queue "time left" column. Both now have regression tests.
