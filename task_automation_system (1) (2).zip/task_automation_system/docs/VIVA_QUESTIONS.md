# Viva Questions & Answers (30)

**1. What is your project about?**
It is a web app that manages tasks and automates the boring parts. It suggests a category and priority using machine learning, detects deadlines written in text, marks late tasks as overdue, sends in-app alerts and reminders, and shows reports.

**2. Why did you choose Streamlit?**
It lets me build an interactive web interface in pure Python, without HTML/JavaScript. That kept the whole project in one language and let me focus on logic and ML.

**3. Why SQLite instead of MySQL?**
SQLite needs no server or installation — the whole database is one file, `data/database.db`. It is perfect for a single-machine project. For many simultaneous users I would move to PostgreSQL.

**4. How is the database created?**
`init_db()` runs on every start with `CREATE TABLE IF NOT EXISTS`, so tables are created the first time and left untouched afterwards. That is why data is not lost on restart.

**5. How are passwords stored?**
Never as plain text. I use PBKDF2-HMAC-SHA256 with a random 16-byte salt and 200,000 iterations. Only the hash and the salt are stored.

**6. What is a salt and why is it needed?**
A random value added to the password before hashing. Two users with the same password get different hashes, and pre-computed "rainbow tables" become useless.

**7. How do you make sure one user cannot see another's tasks?**
Every SQL query includes `WHERE user_id = ?` using the logged-in user's id. A test (`test_users_cannot_touch_each_others_tasks`) proves another user cannot read, edit or delete them.

**8. How do you prevent SQL injection?**
All queries use parameter placeholders (`?`). The database treats the user's input as data, not as SQL code.

**9. Which ML algorithm did you use for categorisation and why?**
TF-IDF features with Logistic Regression. It works well on small text datasets, trains in milliseconds, and gives probabilities that I show as confidence. I compared it with Naive Bayes and Linear SVM using cross-validation; all were similar, and Logistic Regression was slightly best and gives probabilities.

**10. What is TF-IDF?**
Term Frequency × Inverse Document Frequency. It gives a high score to words that appear in a sentence but are rare across all sentences, like "exam" or "meeting", and a low score to common words.

**11. How does Logistic Regression classify text?**
It learns a weight for each word for each category. For a new task it adds up the weights of its words per category and converts the totals into probabilities with the softmax function. The category with the highest probability is chosen.

**12. Where did the training data come from?**
I wrote and labelled a small dataset myself: 150 task descriptions (30 per category) and 132 priority examples. It is documented in `data/training/`.

**13. How did you evaluate the model?**
A stratified 75/25 train-test split (accuracy, precision, recall, F1, confusion matrix) and 5-fold stratified cross-validation. Category: 81.6 % hold-out, 69.3 % CV accuracy.

**14. Why is cross-validation accuracy lower than test accuracy?**
The test set has only 38 examples, so one lucky split can look better. Cross-validation averages 5 different splits, so it is the more reliable estimate.

**15. Is 69 % accuracy good?**
For 5 classes, random guessing gives 20 %, so the model clearly learned. But it is limited by the small dataset; more data would improve it. I show the confidence so the user can override uncertain suggestions.

**16. What is a confusion matrix?**
A table of actual vs predicted classes. Diagonal cells are correct predictions; off-diagonal cells show which categories get confused (in my model, Work vs Personal sometimes).

**17. How does priority prediction work?**
Two separate methods. The ML model uses the text plus days left, urgency and importance with Logistic Regression. The rule-based method adds fixed points for these factors. The final suggestion is the ML result if its confidence is at least 45 %, otherwise the rule result.

**18. Which parts are machine learning and which are rules?**
ML: category classifier and the priority ML model. Rule-based: the priority score, deadline detection from text, and all workflow automation. The UI labels each one.

**19. Why is the priority ML accuracy so high (98.5 %)?**
Because the dataset is small and I labelled it consistently, the patterns are easy to learn. On real users' tasks it would be lower. I mention this as a limitation.

**20. How does deadline detection work?**
With regular expressions. It looks for phrases like "tomorrow", "in 3 days", "by Friday", "20 Nov", "2026-12-05" and times like "5pm", then calculates the date relative to today.

**21. How does overdue detection work?**
Each time a page loads, `run_automation` checks open tasks. If the deadline is in the past and the status is Pending or In Progress, it changes the status to Overdue, creates a notification and writes a log entry.

**22. How do you avoid duplicate notifications when automation runs repeatedly?**
Each notification has a unique `dedupe_key` (type + task id + deadline). The table has a UNIQUE constraint and I use `INSERT OR IGNORE`, so the same alert is inserted only once.

**23. What is the smart score?**
priority weight × 30 + deadline pressure (50 if overdue, otherwise 50 minus 5 per day left) + 5 if in progress. Tasks are sorted by it so the most urgent appear first.

**24. What happens if a user extends the deadline of an overdue task?**
The automation sees the deadline is now in the future and automatically moves the task back to Pending, and logs it.

**25. How are reports generated?**
Tasks are loaded into a Pandas DataFrame, then grouped and counted (value_counts, crosstab). Plotly draws the charts and `to_csv` creates the downloadable file.

**26. How did you test the project?**
57 automated pytest tests for authentication, task CRUD, user isolation, AI predictions, deadline parsing, automation rules, analytics and CSV, plus a full UI journey using Streamlit's AppTest. I also tested manually in the browser.

**27. Did testing find any bugs?**
Yes — the category report crashed when a group had zero tasks, and tasks without a deadline crashed the smart queue. I fixed both and added regression tests.

**28. What is `st.session_state`?**
Streamlit re-runs the script on every interaction, so normal variables reset. `session_state` is a dictionary that survives re-runs; I store the logged-in user, the current page and form values in it.

**29. What are the main limitations?**
Small datasets, English only, in-app notifications only, automation runs only while the app is open, personal models reset on restart, and SQLite is for small scale.

**30. How would you improve the project in future?**
Collect more labelled data and use sentence embeddings, learn continuously from user corrections, add email/push notifications with a background scheduler, team collaboration, calendar sync and move to PostgreSQL with a REST API.
