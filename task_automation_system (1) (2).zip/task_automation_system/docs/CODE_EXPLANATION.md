# Code Explanation — in Simple Language

Use this guide to understand and defend every part of the project. Read it file by file, keeping the code open next to it.

---

## The big picture (say this first in your presentation)

> "The app is split into layers. **app.py** is only the user interface. It calls **business-logic modules**
> (auth, task_manager, ai_engine, automation, analytics). Those modules talk to **SQLite** through database.py
> and to the **Scikit-learn models** in the models folder. Because each file has one job, the code is easy
> to test — I have 57 automated tests."

---

## config.py — the settings file
* Holds lists used everywhere: `CATEGORIES`, `PRIORITIES`, `STATUSES`.
* Holds thresholds: `DUE_SOON_HOURS = 24`, `UPCOMING_HOURS = 72`, `PRIORITY_ML_MIN_CONFIDENCE = 0.45`, `CATEGORY_MIN_CONFIDENCE = 0.30`.
* `get_db_path()` returns `data/database.db`, but tests override it with the `TASK_DB_PATH` environment variable so tests never touch real data.

**Why?** Changing one value here changes the whole app — no "magic numbers" scattered around.

---

## database.py — talking to SQLite
* `SCHEMA` is the SQL that creates 5 tables. `CREATE TABLE IF NOT EXISTS` means: create only if missing → data survives restarts.
* `init_db()` runs the schema and inserts the 5 categories (`INSERT OR IGNORE` avoids duplicates).
* `get_connection()` opens the file, turns on foreign keys, and returns rows that behave like dictionaries.
* `db_cursor()` is a **context manager** (`with ... :`). If the code inside succeeds it **commits**; if anything fails it **rolls back**, so the database is never left half-updated.
* `fetch_all`, `fetch_one`, `execute` are small helpers so other files never write connection code.
* Every query uses `?` placeholders → the database treats user input as data, never as SQL → **prevents SQL injection**.

---

## auth.py — accounts and security
* `hash_password(password, salt)` uses **PBKDF2-HMAC-SHA256** with **200,000 iterations**.
  * *Salt* = 16 random bytes per user (from the `secrets` module). Two users with the same password still get different hashes.
  * *Iterations* make each guess slow for an attacker.
* `verify_password` re-hashes the entered password with the stored salt and compares with `hmac.compare_digest` (constant-time, avoids timing attacks).
* `validate_registration` checks username format, password length / letter+digit, matching confirmation, email format.
* `register_user` → validates → checks the username is free → stores hash + salt (never the password).
* `authenticate` → finds the user → verifies → returns the user **without** hash/salt (`public_user`).
* Logout (in app.py) deletes everything from `st.session_state`.

---

## task_manager.py — CRUD
* **C**reate: `create_task(...)` validates input, converts the category name to its id, stores timestamps. A new task whose deadline is already past is saved as *Overdue*.
* **R**ead: `get_task`, `get_tasks` (with optional filters/search), `get_tasks_df` (returns a Pandas DataFrame for charts).
* **U**pdate: `update_task(user_id, task_id, **fields)` updates only allowed fields (`EDITABLE_FIELDS` whitelist), sets `updated_at`, sets `completed_at` when status becomes Completed and clears it otherwise.
* **D**elete: `delete_task` returns True only if a row was really deleted.
* **Security:** every SQL statement contains `WHERE user_id = ?` → one user can never read or change another user's tasks (there is a test for this).
* `TaskValidationError` is a custom error the UI shows as a friendly message.

---

## models/text_utils.py — cleaning text
`clean_text("Pay the BILL!!")` → `"pay bill"`: lower-case, remove punctuation, remove filler words like *the, and, to*.

---

## models/category_model.py — the ML category classifier
Think of it as a 2-step pipeline (`sklearn.pipeline.Pipeline`):
1. **TfidfVectorizer** turns each sentence into a list of numbers. Each number = how important a word is in this sentence
   (TF, term frequency) × how rare the word is across all sentences (IDF). Common words get small weights; specific words
   like *exam* or *meeting* get big weights. `ngram_range=(1, 2)` also uses word pairs such as *team meeting*.
2. **LogisticRegression** learns, for each category, a weight for every word. To classify, it adds up the weights of the
   words in the sentence and converts the totals to **probabilities** with the softmax function. The highest probability wins.

* `evaluate()` → splits data 75/25 (stratified = same category mix in both parts), measures accuracy, precision, recall,
  F1, the confusion matrix, and runs **5-fold cross-validation** (train 5 times on different 80 % parts, test on the other 20 %).
  It also compares Naive Bayes and Linear SVM.
* `train()` → evaluates, then trains the final model on **all** data (+ the user's tasks when personalising).
* `predict(text)` → returns label, confidence, all probabilities. Confidence < 30 % → suggests *Other*.
* `top_keywords()` → shows the words with the biggest weights → explains what the model learned.

---

## models/priority_model.py — two separate approaches
**A) `PriorityModel` (machine learning)**
* Input = text + `days_left` + `urgency` + `importance`.
* A `ColumnTransformer` handles columns differently: TF-IDF for the text; for numbers, `scale_days` applies
  `log(1 + days)` (0 vs 2 days matters more than 30 vs 32 days) and `StandardScaler` puts all numbers on a similar scale.
* Logistic Regression predicts High / Medium / Low with probabilities. Evaluated exactly like the category model.

**B) `rule_based_priority` (NOT machine learning)**
* Adds fixed points: deadline proximity, urgency, importance, keywords → score → High (≥ 60) / Medium (≥ 30) / Low.
* Returns the list of reasons, e.g. "Due within 1 day (+35)".

**Why both?** ML learns patterns from examples (including borderline cases) but can be uncertain; rules are always explainable.
The UI shows both and labels them clearly.

---

## ai_engine.py — one front door to all AI
* `AIEngine()` trains both models once (≈ 1–2 seconds). In app.py it is cached with `@st.cache_resource`, so it trains only once per app start.
* `suggest_category(title, description, user_id)` → uses the personal model if the user trained one.
* `suggest_priority(...)` → runs ML **and** rules; final = ML if confidence ≥ 45 %, else rules. Also reports whether they agree.
* `detect_deadline(...)` → rule-based text parser.
* `personalise_category_model(user_id, tasks)` → retrains with the user's tasks (needs ≥ 3).

---

## utils/helpers.py — dates and deadline detection
* `now()`, `parse_dt()`, `to_str()`, `format_dt()` keep date handling consistent (`YYYY-MM-DD HH:MM:SS` in the database).
* `time_left_text()` → "in 2 days" / "5 hours overdue".
* `detect_deadline_from_text()` → regular expressions, checked in order: "in N days/hours/weeks" → ISO date → day/month/year
  → month names → keywords (today, tomorrow, next week…) → weekdays. It also finds a time ("5pm", "at 17:30").

---

## automation.py — the workflow engine (rule-based)
`run_automation(user_id)` loops over all **open** tasks of the user:
1. Past deadline and Pending/In Progress → set **Overdue**, notify, log.
2. Overdue but deadline now in the future → back to **Pending**.
3. If auto-escalation is on: overdue → **High**; Low and due within 24 h → **Medium**.
4. Due within 72 h / 24 h → create a notification.
5. Reminder time passed → create a reminder.

`_notify` uses `INSERT OR IGNORE` with a unique `dedupe_key` such as `due_24h:12:2026-11-20 18:00:00`. Because the key is
unique per task + deadline, running automation 100 times still creates the alert only once. If the deadline changes, the key
changes and a fresh alert can be created.

`smart_score(row)` = priority weight × 30 + deadline pressure (50 if overdue, otherwise 50 − 5 per day left) + 5 if in progress.
`organize_tasks(df)` sorts by this score → the "Smart order" everywhere in the app.

---

## analytics.py — numbers, charts, reports
* `summary_stats(df)` → counts per status, completion %, due today / this week, on-time rate.
* `*_distribution` → counts per status/priority/category (always includes zero rows).
* `productivity_series(df, days)` → tasks created vs completed per day.
* `fig_*` functions → Plotly charts with the blue & white style.
* `completion_report`, `pending_report`, `group_report` (Pandas `crosstab`) → tables.
* `to_csv_bytes(df)` → the bytes given to `st.download_button`.

---

## app.py — the Streamlit interface
* Streamlit re-runs the whole script from top to bottom on every click. `st.session_state` remembers things between runs
  (the logged-in user, the current page, form values).
* `main()` → if no user → `auth_screen()`; else run automation → draw sidebar → show the selected page.
* Each page is one function: `page_dashboard`, `page_tasks`, `page_create`, `page_ai`, `page_automation`, `page_reports`.
* **Callbacks** (`on_click=`, `on_change=`) run *before* the next re-run — used to save a task, change status, or apply the detected deadline.
* Create Task shows AI suggestions **live**: every time the title/description changes, the models predict again (it takes milliseconds).
* `flash()` / `show_flash()` keep a success message visible after the page re-runs.

## ui_styles.py — the look
CSS for the navy sidebar, KPI cards, badges and AI boxes. Colours are defined once as CSS variables (`--brand`, `--navy` …).

## tests/ — proof that it works
`conftest.py` gives every test a fresh temporary database. Tests cover auth, tasks, AI, deadline detection, automation,
analytics/CSV and a full UI journey with Streamlit's `AppTest`.
