# Internship Presentation — Slide Content & Speaker Notes
**Project:** AI-Powered Task Automation & Workflow Management System (TaskFlow AI)

The matching slide deck is `TaskFlow_AI_Presentation.pptx` (same order). Bullets go on slides; *Say* = what to speak.

---

## 1. Introduction
* TaskFlow AI — an intelligent task manager built with Python
* Uses Machine Learning to categorise and prioritise tasks
* Automates deadline tracking, reminders and status updates
* Runs fully offline: Streamlit + SQLite + Scikit-learn

*Say:* "Everyone uses to-do lists, but they are passive. My project makes the task list active — it understands the task, suggests what kind of task it is and how urgent it is, and keeps track of deadlines on its own."

## 2. Problem Statement
* Deadlines are missed because nothing warns the user
* Priorities are decided by guesswork
* Categorising and re-ordering tasks is repetitive manual work
* No visibility into productivity trends

## 3. Project Objectives
1. Secure multi-user task management
2. Complete task CRUD with deadlines, priorities, categories, statuses
3. ML-based category suggestion
4. Priority prediction (ML + transparent rules)
5. Automated workflows: overdue, reminders, alerts, smart ordering
6. Dashboards, analytics and CSV reports
7. Persistent storage and automated testing

## 4. Existing System
* Paper lists, spreadsheets, basic to-do apps
* User manually sets category and priority
* Overdue tasks are only noticed by the user
* Advanced tools (Jira, Asana, Todoist AI) are complex, paid or cloud-only
* Little or no explanation of "smart" features

## 5. Proposed System
* Suggests category from text with a trained classifier (with confidence)
* Predicts priority with ML and shows a rule-based score side by side
* Detects deadlines written in plain English ("by Friday at 5pm")
* Automatically marks overdue, restores, escalates, alerts and reminds
* Smart score ordering + analytics + CSV export — free and offline

## 6. Technologies Used
Python · Streamlit (UI) · SQLite (database) · Pandas (data processing) · Scikit-learn (ML) · Plotly (charts) · hashlib PBKDF2 (security) · pytest + Streamlit AppTest (testing) · VS Code

## 7. System Architecture
Three layers:
* **Presentation:** `app.py`, `ui_styles.py`
* **Business logic:** `auth.py`, `task_manager.py`, `ai_engine.py`, `automation.py`, `analytics.py`
* **Data / models:** `database.py` → SQLite file; `models/` → Scikit-learn pipelines trained from CSV datasets

*Say:* "The UI never touches the database directly. That separation is why I could write tests for every module."

## 8. Modules
1. User Authentication 2. Dashboard 3. Task Management 4. AI Categorisation 5. AI Priority Prediction 6. Workflow Automation 7. Reports & Analytics

## 9. Database Design
* `users`, `categories`, `tasks`, `notifications`, `automation_log`
* Foreign keys, CHECK constraints, UNIQUE (username, notification dedupe key)
* Auto-created at start-up; `IF NOT EXISTS` keeps data across restarts
* Parameterised queries prevent SQL injection

## 10. AI/ML Implementation
* **Category:** text → clean → TF-IDF (1–2-grams) → Logistic Regression → probabilities. 150 hand-labelled examples. 5-fold CV 69.3 %, hold-out 81.6 %; compared with Naive Bayes (68.0 %) and Linear SVM (68.7 %).
* **Priority (ML):** TF-IDF text + log(days left), urgency, importance → Logistic Regression. 132 examples. 5-fold CV 98.5 %.
* **Priority (rules, not ML):** points for deadline, urgency, importance, keywords → 88.6 % agreement with labels.
* Final = ML if confidence ≥ 45 %, else rules. Deadline detection & automation = rule-based.

*Say:* "I clearly separate machine learning from rules. The rule-based score is not AI — it is a transparent formula, and I show it next to the ML result so the user can see when they disagree."

## 11. Workflow Diagram
Login → automation runs (overdue / restore / escalate / alerts / reminders) → create task (AI suggestions) → save to SQLite → dashboard & reports update → CSV export.

## 12. Screenshots of the Application
Login, Dashboard, Create Task with AI, AI Insights, Automation Center, Reports (see `docs/screenshots/`).

## 13. Testing
* 57 automated tests (pytest): auth, CRUD, user isolation, AI, deadline parsing, automation, analytics, CSV, full UI journey
* Manual browser walkthrough of every page
* Two bugs found by tests and fixed with regression tests

## 14. Results
* Fully working multi-user web app with 6 pages
* Category model ≈ 69 % CV accuracy on 5 classes (random guess = 20 %)
* Priority ML 98.5 % CV vs rules 88.6 % on the sample data
* Automation removes manual status tracking; alerts are never duplicated
* All 57 tests pass

## 15. Advantages
Free & offline · explainable AI (probabilities, top words, rule reasons) · secure password storage · per-user data isolation · automatic overdue handling · clean, responsive UI · CSV reports · modular, tested code

## 16. Limitations
Small single-annotator datasets · English only · in-app notifications only · automation runs when the app is open · personal models not saved after restart · SQLite for small scale · no team collaboration

## 17. Future Scope
Bigger datasets & transformer embeddings · continuous learning · email/push notifications + background scheduler · teams & assignment · calendar sync · mobile app · PostgreSQL + REST API · completion-time prediction

## 18. Conclusion
* Built a complete AI-assisted task automation platform with real ML and real automation
* Demonstrated data handling, ML evaluation, database design, security and testing
* Honest about limitations; clear path to improve with more data
* "TaskFlow AI turns a passive to-do list into an active assistant."
