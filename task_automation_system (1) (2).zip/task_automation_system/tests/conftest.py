"""Shared pytest fixtures: every test gets its own temporary database."""
import os
import sys

import pytest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)


@pytest.fixture(autouse=True)
def temp_db(tmp_path, monkeypatch):
    monkeypatch.setenv("TASK_DB_PATH", str(tmp_path / "test.db"))
    import database
    database.init_db()
    yield


@pytest.fixture(scope="session")
def engine():
    from ai_engine import AIEngine
    return AIEngine()


@pytest.fixture
def user_id():
    import auth
    import database
    ok, _ = auth.register_user("tester", "secret123", "secret123", "Test User", "t@example.com")
    assert ok
    return database.fetch_one("SELECT id FROM users WHERE username = 'tester'")["id"]


@pytest.fixture
def other_user_id():
    import auth
    import database
    auth.register_user("intruder", "secret123", "secret123")
    return database.fetch_one("SELECT id FROM users WHERE username = 'intruder'")["id"]
