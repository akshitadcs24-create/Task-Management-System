from datetime import timedelta

import pytest

import task_manager as tm
from utils.helpers import now


def test_create_and_read_task(user_id):
    deadline = now() + timedelta(days=2)
    tid = tm.create_task(user_id, "Write report", "Quarterly numbers", "Work", "High", deadline)
    t = tm.get_task(user_id, tid)
    assert t["title"] == "Write report" and t["category"] == "Work"
    assert t["priority"] == "High" and t["status"] == "Pending"
    assert t["deadline"].startswith(deadline.strftime("%Y-%m-%d %H:%M"))
    assert t["created_at"] and t["updated_at"]


def test_update_task_fields(user_id):
    tid = tm.create_task(user_id, "Old title", category="Other", priority="Low")
    assert tm.update_task(user_id, tid, title="New title", category="Study", priority="Medium",
                          description="desc", urgency=5, importance=4)
    t = tm.get_task(user_id, tid)
    assert (t["title"], t["category"], t["priority"], t["urgency"], t["importance"]) == \
        ("New title", "Study", "Medium", 5, 4)


def test_completed_status_sets_and_clears_completed_at(user_id):
    tid = tm.create_task(user_id, "Finish")
    tm.update_status(user_id, tid, "Completed")
    assert tm.get_task(user_id, tid)["completed_at"] is not None
    tm.update_status(user_id, tid, "In Progress")
    assert tm.get_task(user_id, tid)["completed_at"] is None


def test_delete_task(user_id):
    tid = tm.create_task(user_id, "Temp")
    assert tm.delete_task(user_id, tid)
    assert tm.get_task(user_id, tid) is None
    assert not tm.delete_task(user_id, tid)


def test_users_cannot_touch_each_others_tasks(user_id, other_user_id):
    tid = tm.create_task(user_id, "Private task")
    assert tm.get_task(other_user_id, tid) is None
    assert tm.get_tasks(other_user_id) == []
    assert not tm.update_task(other_user_id, tid, title="hacked")
    assert not tm.delete_task(other_user_id, tid)
    assert tm.get_task(user_id, tid)["title"] == "Private task"


def test_validation_errors(user_id):
    with pytest.raises(tm.TaskValidationError):
        tm.create_task(user_id, "   ")
    with pytest.raises(tm.TaskValidationError):
        tm.create_task(user_id, "x", priority="Urgent")
    with pytest.raises(tm.TaskValidationError):
        tm.create_task(user_id, "x", category="Shopping")
    with pytest.raises(tm.TaskValidationError):
        tm.create_task(user_id, "x", urgency=9)


def test_task_created_with_past_deadline_is_overdue(user_id):
    tid = tm.create_task(user_id, "Late", deadline=now() - timedelta(hours=2))
    assert tm.get_task(user_id, tid)["status"] == "Overdue"


def test_filters_and_search(user_id):
    tm.create_task(user_id, "Team meeting", category="Meetings", priority="High")
    tm.create_task(user_id, "Read book", category="Personal", priority="Low")
    assert len(tm.get_tasks(user_id, category="Meetings")) == 1
    assert len(tm.get_tasks(user_id, priority=["High", "Low"])) == 2
    assert tm.get_tasks(user_id, search="book")[0]["title"] == "Read book"
    df = tm.get_tasks_df(user_id)
    assert len(df) == 2 and str(df["created_at"].dtype).startswith("datetime64")


def test_data_persists_across_connections(user_id):
    import database as db
    tid = tm.create_task(user_id, "Persistent")
    db.init_db()  # simulates an app restart: tables are not recreated / wiped
    assert tm.get_task(user_id, tid) is not None
