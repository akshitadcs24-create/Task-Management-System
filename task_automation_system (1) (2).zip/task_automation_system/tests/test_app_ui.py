"""End-to-end UI tests using Streamlit's built-in AppTest (no browser needed)."""
import os

from streamlit.testing.v1 import AppTest

APP = os.path.join(os.path.dirname(os.path.dirname(__file__)), "app.py")


def click(at, label):
    next(b for b in at.button if b.label == label).click()
    return at.run()


def logged_in_app():
    at = AppTest.from_file(APP, default_timeout=60).run()
    at.text_input(key="reg_name").input("Asha Rao")
    at.text_input(key="reg_username").input("asha")
    at.text_input(key="reg_password").input("secret123")
    at.text_input(key="reg_confirm").input("secret123")
    click(at, "Create account")
    assert any("Account created" in s.value for s in at.success)
    at.text_input(key="login_username").input("asha")
    at.text_input(key="login_password").input("secret123")
    click(at, "Log in")
    assert not at.exception
    return at


def test_login_rejects_bad_password():
    at = AppTest.from_file(APP, default_timeout=60).run()
    at.text_input(key="login_username").input("nobody")
    at.text_input(key="login_password").input("wrong")
    click(at, "Log in")
    assert any("Invalid username or password" in e.value for e in at.error)


def test_full_user_journey():
    at = logged_in_app()
    assert at.session_state["user"]["username"] == "asha"

    # Create a task with AI suggestions
    at.radio(key="nav").set_value("Create Task").run()
    at.text_input(key="nt_title").input("Team meeting with the client tomorrow").run()
    assert not at.exception
    click(at, "Create task")
    assert any("created as Meetings" in s.value for s in at.success), [s.value for s in at.success]

    # Load demo data from the dashboard? (only shown when empty) -> use My Tasks instead
    at.radio(key="nav").set_value("My Tasks").run()
    assert not at.exception
    assert "Showing 1 of 1 tasks" in " ".join(c.value for c in at.caption)

    for page in ["Dashboard", "AI Insights", "Automation Center", "Reports"]:
        at.radio(key="nav").set_value(page).run()
        assert not at.exception, page

    click(at, ":material/logout: Log out")
    assert "user" not in at.session_state


def test_demo_data_and_all_pages():
    at = logged_in_app()
    click(at, "Load demo tasks")
    assert any("demo tasks loaded" in s.value for s in at.success)
    for page in ["My Tasks", "Create Task", "AI Insights", "Automation Center", "Reports", "Dashboard"]:
        at.radio(key="nav").set_value(page).run()
        assert not at.exception, page
