import io
from datetime import timedelta

import pandas as pd

import analytics as an
import task_manager as tm
from utils.helpers import now


def seed(user_id):
    tm.create_task(user_id, "A", category="Work", priority="High", status="Completed",
                   deadline=now() + timedelta(days=1))
    tm.create_task(user_id, "B", category="Study", priority="Medium", status="Pending",
                   deadline=now() + timedelta(days=2))
    tm.create_task(user_id, "C", category="Work", priority="Low", status="In Progress")
    tm.create_task(user_id, "D", category="Personal", priority="High", deadline=now() - timedelta(days=1))
    return tm.get_tasks_df(user_id)


def test_summary_stats(user_id):
    s = an.summary_stats(seed(user_id))
    assert (s["total"], s["completed"], s["pending"], s["in_progress"], s["overdue"]) == (4, 1, 1, 1, 1)
    assert s["completion_rate"] == 25.0 and s["on_time_rate"] == 100.0
    assert s["high_priority_open"] == 1


def test_empty_stats():
    s = an.summary_stats(tm.get_tasks_df(12345))
    assert s["total"] == 0 and s["completion_rate"] == 0.0


def test_distributions(user_id):
    df = seed(user_id)
    cat = an.category_distribution(df).set_index("category")["tasks"]
    assert cat["Work"] == 2 and cat["Meetings"] == 0
    pri = an.priority_distribution(df).set_index("priority")["tasks"]
    assert pri["High"] == 2
    rep = an.group_report(df, "priority", ["High", "Medium", "Low"]).set_index("Priority")
    assert rep.loc["High", "Total"] == 2 and rep.loc["High", "Completion %"] == 50.0


def test_reports_and_csv_export(user_id):
    df = seed(user_id)
    comp = an.completion_report(df)
    assert list(comp["Title"]) == ["A"] and comp["On Time"].iloc[0] == "Yes"
    pend = an.pending_report(df)
    assert len(pend) == 3 and "Smart Score" in pend.columns
    back = pd.read_csv(io.BytesIO(an.to_csv_bytes(an.export_frame(df))))
    assert len(back) == 4 and {"Title", "Category", "Priority", "Status", "Deadline"} <= set(back.columns)


def test_productivity_series_and_charts(user_id):
    df = seed(user_id)
    series = an.productivity_series(df, 30)
    assert len(series) == 30 and series["created"].sum() == 4 and series["completed"].sum() == 1
    for fig in (an.fig_status_donut(df), an.fig_priority_bar(df), an.fig_category_pie(df),
                an.fig_productivity(df), an.fig_priority_by_status(df), an.fig_completion_gauge(25)):
        assert fig.to_dict()["data"]


def test_group_report_handles_empty_groups(user_id):
    tm.create_task(user_id, "Only one", priority="High")
    rep = an.group_report(tm.get_tasks_df(user_id), "priority", ["High", "Medium", "Low"]).set_index("Priority")
    assert rep.loc["Low", "Total"] == 0 and rep.loc["Low", "Completion %"] == 0.0
