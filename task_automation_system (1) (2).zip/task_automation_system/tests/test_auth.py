import auth
import database as db


def test_password_hash_uses_random_salt():
    h1, s1 = auth.hash_password("secret123")
    h2, s2 = auth.hash_password("secret123")
    assert s1 != s2 and h1 != h2
    assert auth.verify_password("secret123", h1, s1)
    assert not auth.verify_password("wrong", h1, s1)


def test_register_and_login(user_id):
    user = auth.authenticate("tester", "secret123")
    assert user is not None and user["id"] == user_id
    assert "password_hash" not in user and "salt" not in user


def test_password_is_not_stored_in_plain_text(user_id):
    row = db.fetch_one("SELECT password_hash FROM users WHERE id = ?", (user_id,))
    assert row["password_hash"] != "secret123" and len(row["password_hash"]) == 64


def test_login_wrong_password_or_unknown_user(user_id):
    assert auth.authenticate("tester", "nope12345") is None
    assert auth.authenticate("ghost", "secret123") is None


def test_username_is_case_insensitive(user_id):
    assert auth.authenticate("TESTER", "secret123") is not None


def test_duplicate_username_rejected(user_id):
    ok, msg = auth.register_user("Tester", "another1", "another1")
    assert not ok and "taken" in msg


def test_registration_validation():
    assert not auth.register_user("ab", "secret123", "secret123")[0]          # username too short
    assert not auth.register_user("valid_user", "short", "short")[0]          # password too short
    assert not auth.register_user("valid_user", "abcdefgh", "abcdefgh")[0]    # no digit
    assert not auth.register_user("valid_user", "secret123", "secret124")[0]  # mismatch
    assert not auth.register_user("valid_user", "secret123", "secret123", email="bad-email")[0]
    assert auth.register_user("valid_user", "secret123", "secret123", email="ok@mail.com")[0]
