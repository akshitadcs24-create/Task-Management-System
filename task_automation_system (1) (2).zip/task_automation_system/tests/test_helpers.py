from datetime import datetime

from utils.helpers import detect_deadline_from_text, time_left_text

REF = datetime(2026, 11, 17, 10, 0)  # a Tuesday


def dl(text):
    r = detect_deadline_from_text(text, REF)
    return r["deadline"] if r else None


def test_detect_relative_dates():
    assert dl("finish this tomorrow") == datetime(2026, 11, 18, 18, 0)
    assert dl("submit tomorrow at 5pm") == datetime(2026, 11, 18, 17, 0)
    assert dl("complete in 3 days") == datetime(2026, 11, 20, 18, 0)
    assert dl("reply within 2 hours") == datetime(2026, 11, 17, 12, 0)
    assert dl("do it the day after tomorrow") == datetime(2026, 11, 19, 18, 0)
    assert dl("pay rent today") == datetime(2026, 11, 17, 18, 0)
    assert dl("plan for next week") == datetime(2026, 11, 24, 18, 0)


def test_detect_weekdays():
    assert dl("send report by friday") == datetime(2026, 11, 20, 18, 0)
    assert dl("meeting next tuesday at 10:30") == datetime(2026, 11, 24, 10, 30)


def test_detect_explicit_dates():
    assert dl("exam on 2026-12-05") == datetime(2026, 12, 5, 18, 0)
    assert dl("fees due 05/12/2026") == datetime(2026, 12, 5, 18, 0)
    assert dl("trip on 20 nov") == datetime(2026, 11, 20, 18, 0)
    assert dl("renew by March 3rd") == datetime(2027, 3, 3, 18, 0)


def test_no_deadline_found():
    assert dl("organise the bookshelf") is None
    assert dl("") is None


def test_time_left_text():
    assert time_left_text(datetime(2026, 11, 20, 10, 0), REF) == "in 3 days"
    assert time_left_text(datetime(2026, 11, 17, 7, 0), REF) == "3 hours overdue"
    assert time_left_text(None, REF) == "No deadline"


def test_missing_dates_from_dataframes_are_handled():
    import pandas as pd
    assert time_left_text(pd.NaT, REF) == "No deadline"
    assert time_left_text(float("nan"), REF) == "No deadline"
    assert time_left_text(pd.Timestamp("2026-11-18 10:00"), REF) == "in 24 hours"
