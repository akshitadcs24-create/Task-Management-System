from datetime import timedelta

import automation as auto
import database as db
import task_manager as tm
from utils.helpers import now


def status(user_id, tid):
    return tm.get_task(user_id, tid)["status"]


def test_overdue_detection_and_restore(user_id):
    tid = tm.create_task(user_id, "Report", deadline=now() + timedelta(hours=1), status="In Progress")
    r = auto.run_automation(user_id, reference=now() + timedelta(hours=2))
    assert r["overdue_marked"] == 1 and status(user_id, tid) == "Overdue"
    # Deadline extended -> automatically back to Pending
    tm.update_task(user_id, tid, deadline=now() + timedelta(days=3))
    r = auto.run_automation(user_id)
    assert r["restored"] == 1 and status(user_id, tid) == "Pending"


def test_completed_tasks_are_never_marked_overdue(user_id):
    tid = tm.create_task(user_id, "Done", deadline=now() + timedelta(hours=1), status="Completed")
    auto.run_automation(user_id, reference=now() + timedelta(days=1))
    assert status(user_id, tid) == "Completed"


def test_due_soon_notifications_are_not_duplicated(user_id):
    tm.create_task(user_id, "Soon", deadline=now() + timedelta(hours=5))
    tm.create_task(user_id, "In two days", deadline=now() + timedelta(hours=50))
    tm.create_task(user_id, "Far away", deadline=now() + timedelta(days=10))
    first = auto.run_automation(user_id)
    second = auto.run_automation(user_id)
    assert first["due_soon_alerts"] == 2 and second["due_soon_alerts"] == 0
    types = sorted(n["type"] for n in auto.get_notifications(user_id))
    assert types == ["due_24h", "due_72h"]


def test_reminder_fires_once(user_id):
    deadline = now() + timedelta(hours=10)
    tm.create_task(user_id, "Call bank", deadline=deadline, reminder_at=deadline - timedelta(hours=9))
    assert auto.run_automation(user_id, reference=now())["reminders"] == 0
    assert auto.run_automation(user_id, reference=now() + timedelta(hours=2))["reminders"] == 1
    assert auto.run_automation(user_id, reference=now() + timedelta(hours=3))["reminders"] == 0


def test_priority_escalation_toggle(user_id):
    tid = tm.create_task(user_id, "Low but soon", priority="Low", deadline=now() + timedelta(hours=6))
    auto.run_automation(user_id, escalate=False)
    assert tm.get_task(user_id, tid)["priority"] == "Low"
    auto.run_automation(user_id, escalate=True)
    assert tm.get_task(user_id, tid)["priority"] == "Medium"
    auto.run_automation(user_id, reference=now() + timedelta(hours=7), escalate=True)
    assert tm.get_task(user_id, tid)["priority"] == "High"


def test_automation_log_and_notifications_read(user_id):
    tm.create_task(user_id, "Late", deadline=now() + timedelta(minutes=30))
    auto.run_automation(user_id, reference=now() + timedelta(hours=1))
    assert any(l["action"] == "Marked overdue" for l in auto.get_automation_log(user_id))
    assert auto.unread_count(user_id) >= 1
    auto.mark_all_read(user_id)
    assert auto.unread_count(user_id) == 0


def test_organize_tasks_orders_by_urgency(user_id):
    tm.create_task(user_id, "Low far", priority="Low", deadline=now() + timedelta(days=20))
    tm.create_task(user_id, "High soon", priority="High", deadline=now() + timedelta(hours=3))
    tm.create_task(user_id, "Medium overdue", priority="Medium", deadline=now() - timedelta(hours=3))
    tm.create_task(user_id, "Finished", priority="High", status="Completed")
    ordered = auto.organize_tasks(tm.get_tasks_df(user_id))
    assert list(ordered["title"]) == ["High soon", "Medium overdue", "Low far", "Finished"]


def test_notifications_removed_with_task(user_id):
    tid = tm.create_task(user_id, "Soon", deadline=now() + timedelta(hours=2))
    auto.run_automation(user_id)
    tm.delete_task(user_id, tid)
    assert db.fetch_all("SELECT * FROM notifications WHERE task_id = ?", (tid,)) == []
