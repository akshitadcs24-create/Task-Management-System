from datetime import timedelta

import pytest

from models.priority_model import rule_based_priority
from utils.helpers import now


@pytest.mark.parametrize("text,expected", [
    ("Attend the weekly team meeting with the manager", "Meetings"),
    ("Revise chapters for the semester exam", "Study"),
    ("Pay the electricity bill and buy groceries", "Personal"),
    ("Fix the production bug reported by the client", "Work"),
    ("Zoom call with the vendor", "Meetings"),
    # examples used in docs/TESTING_GUIDE.md (keeps the guide truthful)
    ("Revise chapter 4 for the semester exam", "Study"),
    ("Zoom call with the HR team", "Meetings"),
    ("Pay the water bill", "Personal"),
    ("Fix the production server crash", "Work"),
])
def test_category_prediction(engine, text, expected):
    assert engine.suggest_category(text)["label"] == expected


def test_category_probabilities_valid(engine):
    r = engine.suggest_category("Prepare notes for the operating systems exam")
    assert abs(sum(r["probabilities"].values()) - 1) < 1e-6
    assert 0 <= r["confidence"] <= 1 and "Machine Learning" in r["method"]


def test_empty_text_defaults_to_other(engine):
    r = engine.suggest_category("", "")
    assert r["label"] == "Other" and r["low_confidence"]


def test_category_model_evaluated(engine):
    m = engine.category_model.metrics
    assert m["cv_mean"] > 0.5 and m["test_accuracy"] > 0.5
    assert len(m["confusion_matrix"]) == 5


def test_priority_high_for_urgent_task(engine):
    r = engine.suggest_priority("Fix critical server outage urgent", "", now() + timedelta(hours=5), 5, 5)
    assert r["ml"]["label"] == "High" and r["rule"]["label"] == "High" and r["final"] == "High"


def test_priority_low_for_relaxed_task(engine):
    r = engine.suggest_priority("Organise old photos someday", "", now() + timedelta(days=40), 1, 1)
    assert r["ml"]["label"] == "Low" and r["rule"]["label"] == "Low"


def test_priority_without_deadline(engine):
    r = engine.suggest_priority("Update the documentation", "", None, 3, 3)
    assert r["final"] in ("High", "Medium", "Low") and r["days_left"] is None


def test_rule_based_scoring_is_transparent():
    r = rule_based_priority("submit report asap", 0.5, 5, 5)
    assert r["label"] == "High" and r["score"] == 35 + 30 + 30 + 10
    assert any("asap" in reason for reason in r["reasons"])
    assert rule_based_priority("read a novel", 30, 1, 1)["label"] == "Low"
    assert rule_based_priority("weekly report", 3, 3, 3)["label"] == "Medium"


def test_low_ml_confidence_falls_back_to_rules(engine, monkeypatch):
    monkeypatch.setattr(engine.priority_model, "predict",
                        lambda *a, **k: {"label": "Low", "confidence": 0.34, "probabilities": {}})
    r = engine.suggest_priority("urgent deadline", "", now() + timedelta(hours=3), 5, 5)
    assert r["final"] == r["rule"]["label"] == "High" and "Rule-based" in r["source"]


def test_personalisation(engine):
    tasks = [{"title": "Gardening club session", "description": "", "category": "Personal"}] * 3
    with pytest.raises(ValueError):
        engine.personalise_category_model(999, tasks[:2])
    info = engine.personalise_category_model(999, tasks)
    assert info["user_samples"] == 3
    assert engine.suggest_category("gardening club", user_id=999)["personalised"]
    engine.reset_personalisation(999)
    assert not engine.suggest_category("gardening club", user_id=999)["personalised"]
