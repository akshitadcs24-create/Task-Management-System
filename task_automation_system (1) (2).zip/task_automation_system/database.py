"""
database.py - SQLite database layer.

Responsibilities:
  * Create the database file and all tables automatically on start-up.
  * Provide a safe connection helper (commit on success, rollback on error).
  * Seed the fixed list of task categories.

SQLite stores everything in a single file (data/database.db), so data is
kept when the application restarts.
"""
import os
import sqlite3
from contextlib import contextmanager

from config import CATEGORIES, get_db_path

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    username       TEXT    NOT NULL UNIQUE COLLATE NOCASE,
    full_name      TEXT    NOT NULL DEFAULT '',
    email          TEXT    NOT NULL DEFAULT '',
    password_hash  TEXT    NOT NULL,
    salt           TEXT    NOT NULL,
    auto_escalate  INTEGER NOT NULL DEFAULT 1,
    created_at     TEXT    NOT NULL
);

CREATE TABLE IF NOT EXISTS categories (
    id    INTEGER PRIMARY KEY AUTOINCREMENT,
    name  TEXT NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS tasks (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title         TEXT    NOT NULL,
    description   TEXT    NOT NULL DEFAULT '',
    category_id   INTEGER NOT NULL REFERENCES categories(id),
    priority      TEXT    NOT NULL CHECK (priority IN ('High','Medium','Low')),
    status        TEXT    NOT NULL DEFAULT 'Pending'
                          CHECK (status IN ('Pending','In Progress','Completed','Overdue')),
    deadline      TEXT,
    reminder_at   TEXT,
    urgency       INTEGER NOT NULL DEFAULT 3 CHECK (urgency BETWEEN 1 AND 5),
    importance    INTEGER NOT NULL DEFAULT 3 CHECK (importance BETWEEN 1 AND 5),
    ai_category   TEXT,
    ai_priority   TEXT,
    created_at    TEXT    NOT NULL,
    updated_at    TEXT    NOT NULL,
    completed_at  TEXT
);

CREATE INDEX IF NOT EXISTS idx_tasks_user     ON tasks(user_id);
CREATE INDEX IF NOT EXISTS idx_tasks_deadline ON tasks(deadline);

CREATE TABLE IF NOT EXISTS notifications (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    task_id     INTEGER REFERENCES tasks(id) ON DELETE CASCADE,
    type        TEXT    NOT NULL,
    message     TEXT    NOT NULL,
    dedupe_key  TEXT    NOT NULL,
    is_read     INTEGER NOT NULL DEFAULT 0,
    created_at  TEXT    NOT NULL,
    UNIQUE (user_id, dedupe_key)
);

CREATE TABLE IF NOT EXISTS automation_log (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    task_id     INTEGER REFERENCES tasks(id) ON DELETE SET NULL,
    action      TEXT    NOT NULL,
    details     TEXT    NOT NULL DEFAULT '',
    created_at  TEXT    NOT NULL
);
"""


def get_connection() -> sqlite3.Connection:
    """Open a new connection with dictionary-like rows and foreign keys on."""
    path = get_db_path()
    folder = os.path.dirname(path)
    if folder:
        os.makedirs(folder, exist_ok=True)
    conn = sqlite3.connect(path, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


@contextmanager
def db_cursor():
    """Context manager: yields a cursor, commits on success, rolls back on error."""
    conn = get_connection()
    try:
        cur = conn.cursor()
        yield cur
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db() -> None:
    """Create all tables (if missing) and seed the category list."""
    conn = get_connection()
    try:
        conn.executescript(SCHEMA)
        conn.executemany(
            "INSERT OR IGNORE INTO categories (name) VALUES (?)",
            [(c,) for c in CATEGORIES],
        )
        conn.commit()
    finally:
        conn.close()


def fetch_all(query: str, params: tuple = ()) -> list:
    """Run a SELECT and return a list of plain dictionaries."""
    with db_cursor() as cur:
        cur.execute(query, params)
        return [dict(r) for r in cur.fetchall()]


def fetch_one(query: str, params: tuple = ()):
    """Run a SELECT and return one dictionary (or None)."""
    with db_cursor() as cur:
        cur.execute(query, params)
        row = cur.fetchone()
        return dict(row) if row else None


def execute(query: str, params: tuple = ()) -> int:
    """Run INSERT/UPDATE/DELETE. Returns lastrowid for inserts, else rowcount."""
    with db_cursor() as cur:
        cur.execute(query, params)
        if query.lstrip().upper().startswith("INSERT"):
            return cur.lastrowid
        return cur.rowcount


def get_category_id(name: str) -> int:
    """Translate a category name to its id (unknown names map to 'Other')."""
    row = fetch_one("SELECT id FROM categories WHERE name = ?", (name,))
    if row is None:
        row = fetch_one("SELECT id FROM categories WHERE name = 'Other'")
    return row["id"]
