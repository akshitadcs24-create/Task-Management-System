"""
task_manager.py - Create, read, update and delete (CRUD) tasks.

Every query includes "WHERE user_id = ?" so a user can only ever see or
change their own tasks.
"""
from datetime import datetime

import pandas as pd

import database as db
from config import CATEGORIES, PRIORITIES, STATUSES
from utils.helpers import now, now_str, parse_dt, to_str

TASK_SELECT = """
SELECT t.id, t.user_id, t.title, t.description, c.name AS category, t.priority,
       t.status, t.deadline, t.reminder_at, t.urgency, t.importance,
       t.ai_category, t.ai_priority, t.created_at, t.updated_at, t.completed_at
FROM tasks t JOIN categories c ON c.id = t.category_id
"""

EDITABLE_FIELDS = {"title", "description", "category", "priority", "status",
                   "deadline", "reminder_at", "urgency", "importance",
                   "ai_category", "ai_priority"}


class TaskValidationError(ValueError):
    """Raised when task input is invalid (shown to the user as a message)."""


def _validate(fields: dict) -> None:
    if "title" in fields and not str(fields["title"] or "").strip():
        raise TaskValidationError("Task title cannot be empty.")
    if "title" in fields and len(str(fields["title"])) > 150:
        raise TaskValidationError("Task title must be 150 characters or fewer.")
    if "category" in fields and fields["category"] not in CATEGORIES:
        raise TaskValidationError(f"Unknown category: {fields['category']}")
    if "priority" in fields and fields["priority"] not in PRIORITIES:
        raise TaskValidationError(f"Unknown priority: {fields['priority']}")
    if "status" in fields and fields["status"] not in STATUSES:
        raise TaskValidationError(f"Unknown status: {fields['status']}")
    for key in ("urgency", "importance"):
        if key in fields and not 1 <= int(fields[key]) <= 5:
            raise TaskValidationError(f"{key.title()} must be between 1 and 5.")
    for key in ("deadline", "reminder_at"):
        if fields.get(key) not in (None, "") and parse_dt(fields[key]) is None:
            raise TaskValidationError(f"Invalid date for {key}.")


def _dt_or_none(value):
    if value in (None, ""):
        return None
    return to_str(value) if isinstance(value, datetime) else to_str(parse_dt(value))


def create_task(user_id: int, title: str, description: str = "", category: str = "Other",
                priority: str = "Medium", deadline=None, status: str = "Pending",
                urgency: int = 3, importance: int = 3, reminder_at=None,
                ai_category: str | None = None, ai_priority: str | None = None) -> int:
    fields = dict(title=title, description=description, category=category, priority=priority,
                  status=status, urgency=urgency, importance=importance,
                  deadline=deadline, reminder_at=reminder_at)
    _validate(fields)
    ts = now_str()
    deadline_s = _dt_or_none(deadline)
    # A brand-new task whose deadline has already passed is immediately overdue.
    if status in ("Pending", "In Progress") and deadline_s and parse_dt(deadline_s) < now():
        status = "Overdue"
    return db.execute(
        """INSERT INTO tasks (user_id, title, description, category_id, priority, status,
               deadline, reminder_at, urgency, importance, ai_category, ai_priority,
               created_at, updated_at, completed_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (user_id, title.strip(), (description or "").strip(), db.get_category_id(category),
         priority, status, deadline_s, _dt_or_none(reminder_at), int(urgency), int(importance),
         ai_category, ai_priority, ts, ts, ts if status == "Completed" else None),
    )


def get_task(user_id: int, task_id: int) -> dict | None:
    return db.fetch_one(TASK_SELECT + " WHERE t.user_id = ? AND t.id = ?", (user_id, task_id))


def get_tasks(user_id: int, status=None, category=None, priority=None, search: str | None = None) -> list[dict]:
    """Return the user's tasks, optionally filtered. Each filter can be a value or a list."""
    query, params = TASK_SELECT + " WHERE t.user_id = ?", [user_id]
    for column, value in (("t.status", status), ("c.name", category), ("t.priority", priority)):
        if value:
            values = value if isinstance(value, (list, tuple)) else [value]
            query += f" AND {column} IN ({','.join('?' * len(values))})"
            params.extend(values)
    if search:
        query += " AND (t.title LIKE ? OR t.description LIKE ?)"
        params.extend([f"%{search}%", f"%{search}%"])
    query += " ORDER BY t.deadline IS NULL, t.deadline, t.id"
    return db.fetch_all(query, tuple(params))


def get_tasks_df(user_id: int) -> pd.DataFrame:
    """All tasks of a user as a pandas DataFrame with parsed dates."""
    df = pd.DataFrame(get_tasks(user_id))
    columns = ["id", "user_id", "title", "description", "category", "priority", "status",
               "deadline", "reminder_at", "urgency", "importance", "ai_category",
               "ai_priority", "created_at", "updated_at", "completed_at"]
    if df.empty:
        df = pd.DataFrame(columns=columns)
    for col in ("deadline", "reminder_at", "created_at", "updated_at", "completed_at"):
        df[col] = pd.to_datetime(df[col], errors="coerce")
    return df


def update_task(user_id: int, task_id: int, **fields) -> bool:
    """Update the given fields. Returns False if the task does not exist / is not yours."""
    fields = {k: v for k, v in fields.items() if k in EDITABLE_FIELDS}
    if not fields:
        return False
    _validate(fields)
    current = get_task(user_id, task_id)
    if current is None:
        return False

    sets, params = [], []
    for key, value in fields.items():
        if key == "category":
            sets.append("category_id = ?"); params.append(db.get_category_id(value))
        elif key in ("deadline", "reminder_at"):
            sets.append(f"{key} = ?"); params.append(_dt_or_none(value))
        elif key == "title":
            sets.append("title = ?"); params.append(str(value).strip())
        else:
            sets.append(f"{key} = ?"); params.append(value)

    if "status" in fields:
        if fields["status"] == "Completed" and current["status"] != "Completed":
            sets.append("completed_at = ?"); params.append(now_str())
        elif fields["status"] != "Completed":
            sets.append("completed_at = NULL")

    sets.append("updated_at = ?"); params.append(now_str())
    params.extend([user_id, task_id])
    db.execute(f"UPDATE tasks SET {', '.join(sets)} WHERE user_id = ? AND id = ?", tuple(params))
    return True


def update_status(user_id: int, task_id: int, status: str) -> bool:
    return update_task(user_id, task_id, status=status)


def delete_task(user_id: int, task_id: int) -> bool:
    return db.execute("DELETE FROM tasks WHERE user_id = ? AND id = ?", (user_id, task_id)) > 0


def get_categories() -> list[str]:
    return [r["name"] for r in db.fetch_all("SELECT name FROM categories ORDER BY id")]
