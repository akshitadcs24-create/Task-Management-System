@echo off
REM Windows helper: creates a virtual environment (first run only), installs packages and starts the app.
if not exist venv (
    python -m venv venv
)
call venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
