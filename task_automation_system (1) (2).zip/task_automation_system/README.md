# TaskFlow AI — AI-Powered Task Automation & Workflow Management System

A complete, working task management application built with **Python, Streamlit, SQLite, Pandas, Scikit-learn and Plotly**.
It helps users create, organise, prioritise, monitor and automate their daily tasks, using **real machine-learning
models** for categorisation and priority prediction plus **transparent rule-based automation** for workflows.

> Everything runs locally and offline. No paid APIs, no subscriptions, no internet connection needed after installation.

---

## 1. Introduction

Students and professionals juggle tasks from study, work, meetings and personal life. Most to-do apps are passive lists:
the user has to decide the category, guess the priority, remember deadlines and notice when something is late.
**TaskFlow AI** automates these decisions. It reads the task description, suggests a category and priority with ML,
detects deadlines written in plain English, marks late tasks as overdue, sends in-app reminders and orders the task
list by urgency.

## 2. Problem Statement

Manual task management causes:
* **Missed deadlines** — nobody tells the user that a task is about to become (or already is) late.
* **Poor prioritisation** — users treat all tasks equally or prioritise by gut feeling.
* **Repetitive manual work** — categorising, re-ordering and updating statuses by hand.
* **No insight** — users cannot see their productivity trends or where their time goes.

## 3. Objectives

1. Build secure, multi-user task management (register, login, logout, per-user data).
2. Provide full task CRUD with descriptions, deadlines, priorities, categories and statuses.
3. Implement an **ML classifier** (Scikit-learn) that suggests task categories from text.
4. Implement **priority prediction** using an ML model *and* a clearly separate rule-based score.
5. Automate workflows: overdue detection, status updates, deadline alerts, reminders, smart ordering.
6. Provide dashboards, analytics and downloadable CSV reports.
7. Store all data persistently in SQLite and verify the system with automated tests.

## 4. Technologies Used

| Layer | Technology | Why |
|---|---|---|
| Language | Python 3.10+ | Simple, huge ecosystem for data & ML |
| Frontend / UI | Streamlit | Build interactive web apps in pure Python |
| Database | SQLite (`sqlite3`, built-in) | Zero-setup, file-based, persistent |
| Data processing | Pandas | Filtering, grouping, reports, CSV export |
| Machine learning | Scikit-learn | TF-IDF, Logistic Regression, evaluation tools |
| Visualisation | Plotly | Interactive charts |
| Security | `hashlib.pbkdf2_hmac`, `secrets`, `hmac` (built-in) | Salted password hashing |
| Testing | pytest + Streamlit `AppTest` | Unit, integration and UI tests |
| IDE | VS Code | Recommended editor |

## 5. System Requirements

* Windows 10/11, macOS or Linux
* **Python 3.10 or newer** (3.11 / 3.12 / 3.13 tested-compatible; developed and tested on 3.13)
* ~500 MB free disk space for packages
* Any modern browser (Chrome, Edge, Firefox)

## 6. Installation

Open the project folder in VS Code, then open a terminal (**Terminal → New Terminal**).

**Windows (PowerShell or Command Prompt)**
```bash
cd task_automation_system
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

**macOS / Linux**
```bash
cd task_automation_system
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

> If PowerShell blocks `activate`, run once: `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`

## 7. Running the Application

```bash
streamlit run app.py
```
The browser opens at **http://localhost:8501**. The database file `data/database.db` is created automatically on first start.

Shortcut scripts: double-click `run_app.bat` (Windows) or run `./run_app.sh` (macOS/Linux) — they create the virtual
environment, install packages and start the app.

**Quick demo:** create an account → log in → click **Load demo tasks** on the empty dashboard. This inserts 20 realistic tasks
(categorised and prioritised by the AI engine) so every chart, report and automation has data.

Other commands:
```bash
python -m pytest -v          # run all 57 automated tests
python evaluate_models.py    # print ML evaluation metrics in the terminal
```

## 8. Project Architecture

```text
task_automation_system/
├── app.py                 # Streamlit UI: login, dashboard, tasks, AI, automation, reports
├── config.py              # Constants: categories, priorities, statuses, paths, thresholds
├── database.py            # SQLite schema, auto-creation, connection helpers
├── auth.py                # Registration, login, PBKDF2 password hashing, validation
├── task_manager.py        # Task CRUD + validation + per-user isolation
├── ai_engine.py           # Facade combining ML models + rule-based logic
├── automation.py          # Workflow rules, notifications, reminders, smart ordering
├── analytics.py           # Statistics, Plotly charts, reports, CSV export
├── ui_styles.py           # Custom CSS (blue & white theme) + HTML helpers
├── evaluate_models.py     # Prints model evaluation in the terminal
├── models/
│   ├── text_utils.py      # Text cleaning shared by both models
│   ├── category_model.py  # ML: TF-IDF + Logistic Regression (category)
│   └── priority_model.py  # ML priority model + separate rule-based scorer
├── utils/
│   ├── helpers.py         # Date helpers + rule-based deadline detection
│   └── demo_data.py       # Sample tasks for demonstrations
├── data/
│   ├── database.db        # Created automatically (not shipped)
│   └── training/
│       ├── category_training.csv   # 150 labelled examples
│       └── priority_training.csv   # 132 labelled examples
├── tests/                 # 57 pytest tests (unit + integration + UI)
├── docs/                  # Presentation, viva questions, code guide, screenshots
├── .streamlit/config.toml # Theme
├── requirements.txt
├── run_app.bat / run_app.sh
└── README.md
```

**Layered design**

```text
            +------------------------------------------------------+
  UI        |  app.py (Streamlit pages)  +  ui_styles.py (CSS)     |
            +---------------------------+--------------------------+
                                        |
            +-----------+-----------+---+--------+-----------+
  Logic     | auth.py   | task_     | ai_engine  | automation| analytics.py
            |           | manager.py| .py        | .py       | (Pandas + Plotly)
            +-----+-----+-----+-----+-----+------+-----+-----+
                  |           |           |            |
            +-----+-----------+-----+   +-+------------+---------+
  Data      | database.py (SQLite)  |   | models/ (Scikit-learn) |
            | data/database.db      |   | data/training/*.csv    |
            +-----------------------+   +------------------------+
```

## 9. Modules and Functionalities

### Module 1 — User Authentication (`auth.py`)
* Registration with validation (username 3–30 chars; password ≥ 6 chars with a letter and a digit; optional email check).
* Passwords hashed with **PBKDF2-HMAC-SHA256, 200,000 iterations, random 16-byte salt per user**; compared with `hmac.compare_digest`.
* Login, logout (clears the session), case-insensitive usernames, duplicate-username protection.
* Every task query filters by `user_id`, so users can only see and change their own data (tested).

### Module 2 — Dashboard
Total, completed, pending, in-progress and overdue counts, completion %, on-time rate, progress bar, overdue/due-soon
banners, status donut, priority bar, category pie, 14-day productivity chart, completion gauge, “Up next” smart queue and
“Due in the next 3 days”.

### Module 3 — Task Management (`task_manager.py`)
Create, edit, delete (with confirmation), title, description, deadline (date + time), priority, category, status,
urgency (1–5), importance (1–5) and optional reminder. Quick status change from the list; search, filters and four sort modes.
Timestamps `created_at`, `updated_at`, `completed_at` are maintained automatically.

### Module 4 — AI Task Categorisation (MACHINE LEARNING)
See section 11. Suggests Work / Study / Personal / Meetings / Other while you type, with a confidence score and a
probability chart. The user can accept the suggestion or override it.

### Module 5 — AI Priority Prediction (ML + RULES, clearly separated)
Two independent methods shown side by side, each labelled **MACHINE LEARNING** or **RULE-BASED** in the UI.

### Module 6 — Workflow Automation (`automation.py`, RULE-BASED)
Runs automatically on every page load (and on demand via **Run automation now**):

| Rule | Trigger | Automatic action |
|---|---|---|
| Overdue detection | Pending / In Progress task past deadline | Status → Overdue, notification, log entry |
| Status restore | Overdue task whose deadline was extended | Status → Pending, log entry |
| Priority escalation (toggle) | Low task due ≤ 24 h / any overdue task | Low → Medium / → High, log entry |
| Deadline alerts | Due within 72 h and within 24 h | In-app notification |
| Reminders | User-selected reminder time reached | In-app reminder |
| Smart ordering | Any task list | Sorted by smart score |

Notifications carry a unique `dedupe_key`, so an alert is created only once even though automation runs constantly.

### Module 7 — Reports & Analytics (`analytics.py`)
Completion report (with on-time flag), pending report (smart-ordered), priority-wise and category-wise reports
(crosstab by status + completion %), productivity report (created vs completed per day), period filter and
**CSV download** for every report plus a full export.

## 10. Database Design (SQLite)

| Table | Key columns | Purpose |
|---|---|---|
| `users` | id (PK), username (UNIQUE, case-insensitive), full_name, email, password_hash, salt, auto_escalate, created_at | Accounts |
| `categories` | id (PK), name (UNIQUE) | Work, Study, Personal, Meetings, Other |
| `tasks` | id (PK), user_id (FK→users), category_id (FK→categories), title, description, priority (CHECK), status (CHECK), deadline, reminder_at, urgency (1–5), importance (1–5), ai_category, ai_priority, created_at, updated_at, completed_at | Tasks |
| `notifications` | id (PK), user_id (FK), task_id (FK), type, message, dedupe_key, is_read, created_at, UNIQUE(user_id, dedupe_key) | In-app alerts |
| `automation_log` | id (PK), user_id (FK), task_id (FK), action, details, created_at | Audit trail of automatic actions |

```text
users 1 ──< tasks >── 1 categories
users 1 ──< notifications >── 0..1 tasks
users 1 ──< automation_log >── 0..1 tasks
```
* Foreign keys are enforced (`PRAGMA foreign_keys = ON`); deleting a task cascades to its notifications.
* `CHECK` constraints guarantee only valid priorities, statuses and urgency/importance values are stored.
* Tables are created with `CREATE TABLE IF NOT EXISTS`, so restarting the app never wipes data.
* All SQL uses parameter placeholders (`?`) — protection against SQL injection.

## 11. AI / ML Implementation

### 11.1 Category model — Machine Learning
* **Dataset:** `data/training/category_training.csv`, 150 short task descriptions (30 per category), written and labelled by hand for this project.
* **Pre-processing:** lower-case, remove punctuation, remove a small custom stop-word list. (scikit-learn's built-in list was avoided because it deletes useful words like *call*, *bill* and *fill*.)
* **Features:** TF-IDF on word unigrams and bigrams (`sublinear_tf=True`).
* **Classifier:** multinomial Logistic Regression (`C=10`) — gives a probability for each category.
* **Low-confidence handling:** if the top probability < 30 %, the app suggests *Other* and says it is low-confidence.
* **Evaluation (reproduce with `python evaluate_models.py`):**

| Metric | Value |
|---|---|
| Hold-out test accuracy (75/25 stratified split, 38 test samples) | 81.6 % |
| 5-fold stratified cross-validation accuracy | 69.3 % ± 8.0 % |
| Naive Bayes / Linear SVM (5-fold CV, for comparison) | 68.0 % / 68.7 % |

* **Explainability:** the AI Insights page lists the words with the highest learned weight per category (e.g. Meetings: *meeting, call, attend, team*).
* **Personalisation:** “Retrain with my tasks” adds the user’s own labelled tasks to the training set and trains a personal model (kept in memory).

### 11.2 Priority prediction — ML model **and** separate rule-based logic

**A) ML model (`PriorityModel`)**
* **Dataset:** `data/training/priority_training.csv`, 132 hand-labelled rows: text, days_left, urgency, importance → High/Medium/Low. Includes ~37 deliberately borderline cases (e.g. a trivial task due tomorrow labelled *Low*).
* **Features:** TF-IDF of text + numeric features: `log(1 + days_left)` (clipped 0–60), urgency, importance (standard-scaled) via a `ColumnTransformer`.
* **Classifier:** Logistic Regression. Tasks without a deadline use days_left = 30.
* **Evaluation:** hold-out accuracy 100 % (33 samples), 5-fold CV 98.5 % ± 1.8 %. Random Forest 90.9 %, Decision Tree 99.2 %. Logistic Regression was kept because it gives smooth probabilities used for the confidence threshold; the difference to the tree is within one standard deviation.
* **Honest note:** these scores are high because one person labelled a small, consistent dataset — they will be lower on real users’ tasks.

**B) Rule-based score (`rule_based_priority`) — NOT machine learning**

| Factor | Points |
|---|---|
| Deadline | overdue +40 · ≤1 day +35 · ≤3 days +25 · ≤7 days +15 · ≤14 days +8 |
| Urgency 1–5 | (u − 1) × 7.5 |
| Importance 1–5 | (i − 1) × 7.5 |
| Keywords | urgent/asap/critical/today… +10 · someday/later… −10 |
| Result | ≥ 60 High · ≥ 30 Medium · else Low |

The rule-based score agrees with the human labels on 88.6 % of the dataset — the ML model learned the borderline cases better.

**Final suggestion:** ML prediction if its confidence ≥ 45 %, otherwise the rule-based result. The UI always shows both, their agreement, and the source used.

### 11.3 Deadline detection — rule-based
`utils/helpers.py` uses regular expressions to detect phrases such as *today, tonight, tomorrow, day after tomorrow,
in 3 days, within 2 hours, next week, end of month, by Friday, next Tuesday, 2026-12-05, 05/12/2026 (day-first),
20 Nov, March 3rd* plus times like *5pm, 5:30 pm, at 17:30, noon*. Default time is 18:00.

## 12. Workflow Explanation

```text
 Register/Login ──> session stores user (no password)
        │
        ▼
 Every page load ──> run_automation(user)
        │             ├─ overdue? → status Overdue + alert + log
        │             ├─ deadline extended? → back to Pending
        │             ├─ escalate priority (optional)
        │             ├─ due ≤72h / ≤24h → alert (once)
        │             └─ reminder time reached → reminder (once)
        ▼
 Create Task: type title/description
        ├─ ML category suggestion (probabilities)
        ├─ ML priority + rule-based priority → final suggestion
        └─ rule-based deadline detection → "Use detected deadline"
        ▼
 Save → SQLite (tasks) → automation re-runs → dashboard / reports update
        ▼
 Reports → Pandas aggregation → Plotly charts → CSV download
```

## 13. Testing

Run: `python -m pytest -v` → **57 tests, all passing** (last run on the delivered code).

| Area | File | What is verified |
|---|---|---|
| Registration & login | `tests/test_auth.py` | salted hashes differ, verify, login, wrong password, case-insensitive username, duplicates, validation rules |
| Task CRUD | `tests/test_tasks.py` | create/read/update/delete, completed_at handling, validation, **user isolation**, past deadline → Overdue, filters/search, persistence after restart |
| AI category | `tests/test_ai.py` | 9 example predictions, probabilities sum to 1, empty text → Other, metrics exist |
| Priority | `tests/test_ai.py` | ML & rules → High for urgent, Low for relaxed, exact rule score, low-confidence fallback, personalisation |
| Deadline detection | `tests/test_helpers.py` | 13 phrase formats, no-deadline case, time-left text, missing dates |
| Workflow automation | `tests/test_automation.py` | overdue + restore, completed untouched, alert de-duplication, reminders fire once, escalation toggle, log, smart order, cascade delete |
| Dashboard analytics & CSV | `tests/test_analytics.py` | stats, distributions, empty groups, reports, CSV round-trip, productivity series, all charts build |
| Full UI | `tests/test_app_ui.py` | Streamlit AppTest: register → login → create task with AI → list → every page → logout; demo data on all pages; bad login rejected |

The app was also exercised manually in a real browser (Chromium): registration, login, demo data, editing,
creating a task with the detected deadline, every page and tab, and the CSV download. Screenshots are in `docs/screenshots/`.
A step-by-step manual test script is in `docs/TESTING_GUIDE.md`.

## 14. Limitations
* **Small training data** (150 + 132 examples, one annotator): limited vocabulary; accuracy figures come from small test sets and vary with the split; real-world accuracy will be lower.
* English only; spelling mistakes and one-word tasks reduce accuracy.
* Personalised models live in memory and reset when the app restarts.
* Notifications are in-app only (no email/SMS/push) and automation runs when the user opens the app (no background scheduler).
* Login session is per browser tab; refreshing the page requires logging in again (Streamlit session behaviour).
* SQLite suits a single machine / small team, not thousands of concurrent users.
* No task sharing or team assignment between users.

## 15. Future Scope
* Larger, crowd-labelled dataset; transformer embeddings (e.g. sentence-transformers) for better accuracy.
* Continuous learning from every user correction; periodic retraining and model persistence with `joblib`.
* Email / Telegram / push notifications and a background scheduler (APScheduler / cron).
* Team workspaces, task assignment, comments and recurring tasks.
* Google Calendar / Outlook sync; mobile app; PostgreSQL + REST API (FastAPI) for scale.
* Productivity forecasting (predict completion time) and workload balancing.

---
*Developed as an internship project. All code, data and documentation are original and free to use for learning.*
