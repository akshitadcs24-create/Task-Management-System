"""
ai_engine.py - Single entry point for all AI features used by the app.

* suggest_category()  -> MACHINE LEARNING (models/category_model.py)
* suggest_priority()  -> MACHINE LEARNING prediction + RULE-BASED score,
                         both returned side by side and clearly labelled.
* detect_deadline()   -> RULE-BASED text parsing (utils/helpers.py)

The models are trained once when the engine is created (training on the
small datasets takes about a second) and then reused.
"""
from config import PRIORITY_ML_MIN_CONFIDENCE
from models.category_model import CategoryModel
from models.priority_model import PriorityModel, rule_based_priority
from utils.helpers import days_until, detect_deadline_from_text

_ENGINE = None


class AIEngine:
    def __init__(self, evaluate: bool = True):
        self.category_model = CategoryModel().train(evaluate=evaluate)
        self.priority_model = PriorityModel().train(evaluate=evaluate)
        # Optional personalised category models: {user_id: CategoryModel}
        self.user_category_models: dict[int, CategoryModel] = {}

    # ------------------------------------------------------------------
    @staticmethod
    def _combine(title: str, description: str) -> str:
        return f"{title or ''} {description or ''}".strip()

    def suggest_category(self, title: str, description: str = "", user_id: int | None = None) -> dict:
        model = self.user_category_models.get(user_id, self.category_model)
        result = model.predict(self._combine(title, description))
        result["method"] = f"Machine Learning ({model.name})"
        result["personalised"] = user_id in self.user_category_models
        return result

    def suggest_priority(self, title: str, description: str = "", deadline=None,
                         urgency: int = 3, importance: int = 3) -> dict:
        text = self._combine(title, description)
        days = days_until(deadline) if deadline else None
        ml = self.priority_model.predict(text, days, urgency, importance)
        rule = rule_based_priority(text, days, urgency, importance)
        if ml["confidence"] >= PRIORITY_ML_MIN_CONFIDENCE:
            final, source = ml["label"], "Machine Learning model"
        else:
            final, source = rule["label"], "Rule-based fallback (ML confidence was low)"
        return {
            "ml": ml,
            "rule": rule,
            "final": final,
            "source": source,
            "agree": ml["label"] == rule["label"],
            "days_left": days,
        }

    @staticmethod
    def detect_deadline(title: str, description: str = ""):
        return detect_deadline_from_text(f"{title or ''} {description or ''}")

    # ------------------------------------------------------------------
    def personalise_category_model(self, user_id: int, tasks: list[dict]) -> dict:
        """Retrain the category model with the user's own labelled tasks
        added to the sample dataset (simple 'learning from feedback')."""
        texts = [self._combine(t["title"], t.get("description", "")) for t in tasks]
        labels = [t["category"] for t in tasks]
        if len(texts) < 3:
            raise ValueError("You need at least 3 tasks to personalise the model.")
        model = CategoryModel().train(extra_texts=texts, extra_labels=labels, evaluate=False)
        self.user_category_models[user_id] = model
        return {"user_samples": model.n_user_samples, "total_samples": model.n_training_samples}

    def reset_personalisation(self, user_id: int) -> None:
        self.user_category_models.pop(user_id, None)


def get_engine() -> AIEngine:
    """Module-level singleton so the models are trained only once."""
    global _ENGINE
    if _ENGINE is None:
        _ENGINE = AIEngine()
    return _ENGINE
