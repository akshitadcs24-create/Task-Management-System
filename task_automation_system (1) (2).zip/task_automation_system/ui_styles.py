"""
ui_styles.py - Custom CSS for a clean, professional blue & white look,
plus small HTML helpers (KPI cards, badges) used by app.py.
"""
import html

CSS = """
<style>
:root {
  --brand: #1F5EFF;
  --brand-dark: #1745C2;
  --navy: #0F1E3D;
  --ink: #0F1E3D;
  --muted: #5B6B8C;
  --line: #E3EAF7;
  --bg: #F5F8FE;
  --card: #FFFFFF;
  --success: #16A34A;
  --warning: #D97706;
  --danger: #DC2626;
}

.block-container { padding-top: 1.6rem; padding-bottom: 3rem; max-width: 1280px; }
#MainMenu, footer { visibility: hidden; }
[data-testid="stHeader"] { background: transparent; }
h1, h2, h3 { color: var(--navy); letter-spacing: -0.02em; }

/* ---------- Sidebar ---------- */
[data-testid="stSidebar"] {
  background: linear-gradient(180deg, #0F1E3D 0%, #132B5E 100%);
}
[data-testid="stSidebar"] p, [data-testid="stSidebar"] span, [data-testid="stSidebar"] label,
[data-testid="stSidebar"] div { color: #DCE6FF; }
[data-testid="stSidebar"] [data-testid="stRadio"], [data-testid="stSidebar"] [role="radiogroup"] { width: 100%; }
[data-testid="stSidebar"] [data-testid="stRadioOption"] {
  padding: 0.6rem 0.85rem; border-radius: 10px; margin: 0 0 3px 0; width: 100%; box-sizing: border-box;
  transition: background 0.15s ease; cursor: pointer;
}
[data-testid="stSidebar"] [data-testid="stRadioOption"]:hover { background: rgba(255,255,255,0.08); }
[data-testid="stSidebar"] [data-testid="stRadioOption"][data-selected="true"],
[data-testid="stSidebar"] [data-testid="stRadioOption"]:has(input:checked) {
  background: var(--brand); box-shadow: 0 6px 18px -6px rgba(31,94,255,0.7);
}
[data-testid="stSidebar"] [data-testid="stRadioOption"] > div > div:not([data-testid="stMarkdownContainer"]) { display: none; }
[data-testid="stSidebar"] [data-testid="stRadioOption"] p { font-weight: 600; font-size: 0.95rem; color: #FFFFFF; }
[data-testid="stSidebar"] [data-testid="stRadioOption"] [role="img"] { margin-right: 6px; opacity: 0.9; }
[data-testid="stSidebar"] .stButton button {
  background: rgba(255,255,255,0.08); color: #FFFFFF; border: 1px solid rgba(255,255,255,0.18);
  width: 100%;
}
[data-testid="stSidebar"] .stButton button:hover { background: rgba(255,255,255,0.16); color: #FFFFFF; }
.brand { display:flex; align-items:center; gap:10px; margin: 0.2rem 0 1.2rem 0; }
.brand-logo { width:38px; height:38px; border-radius:11px; display:flex; align-items:center;
  justify-content:center; background: linear-gradient(135deg,#1F5EFF,#5B8CFF); color:#fff !important;
  font-weight:800; font-size:18px; box-shadow: 0 6px 16px -4px rgba(31,94,255,0.8); }
.brand-name { font-weight:800; font-size:1.15rem; color:#FFFFFF !important; line-height:1.1; }
.brand-sub { font-size:0.72rem; color:#9FB4E6 !important; }
.user-chip { background: rgba(255,255,255,0.07); border:1px solid rgba(255,255,255,0.12);
  border-radius:12px; padding:0.7rem 0.8rem; margin-bottom: 1rem; }
.user-chip b { color:#FFFFFF !important; }
.notif-pill { display:inline-block; background:#DC2626; color:#fff !important; border-radius:999px;
  padding:1px 9px; font-size:0.75rem; font-weight:700; margin-left:6px; }

/* ---------- Page header ---------- */
.page-head { display:flex; justify-content:space-between; align-items:flex-end; margin-bottom: 1.1rem; }
.page-title { font-size: 1.75rem; font-weight: 800; color: var(--navy); margin:0; }
.page-sub { color: var(--muted); font-size: 0.95rem; margin-top: 2px; }

/* ---------- KPI cards ---------- */
.kpi-grid { display:grid; grid-template-columns: repeat(6, minmax(0,1fr)); gap: 14px; margin-bottom: 1rem; }
@media (max-width: 1100px) { .kpi-grid { grid-template-columns: repeat(3, minmax(0,1fr)); } }
@media (max-width: 640px)  { .kpi-grid { grid-template-columns: repeat(2, minmax(0,1fr)); } }
.kpi { background: var(--card); border:1px solid var(--line); border-radius: 16px; padding: 1rem 1.1rem;
  box-shadow: 0 1px 2px rgba(15,30,61,0.04), 0 8px 24px -16px rgba(15,30,61,0.18); position:relative; overflow:hidden; }
.kpi::before { content:""; position:absolute; left:0; top:0; bottom:0; width:4px; background: var(--accent, var(--brand)); }
.kpi-label { color: var(--muted); font-size: 0.78rem; font-weight:600; text-transform: uppercase; letter-spacing: .05em; }
.kpi-value { color: var(--navy); font-size: 1.9rem; font-weight: 800; margin-top: 4px; line-height:1.1; }
.kpi-sub { color: var(--muted); font-size: 0.8rem; margin-top: 4px; }
.kpi.primary { background: linear-gradient(135deg,#1F5EFF,#3D7BFF); border:none; }
.kpi.primary .kpi-label, .kpi.primary .kpi-sub { color: #DCE6FF; }
.kpi.primary .kpi-value { color: #FFFFFF; }
.kpi.primary::before { display:none; }

/* ---------- Cards & badges ---------- */
.card { background: var(--card); border:1px solid var(--line); border-radius: 16px; padding: 1rem 1.2rem; }
.section-title { font-weight:700; color: var(--navy); font-size:1.05rem; margin: 0.4rem 0 0.6rem; }
.badge { display:inline-block; padding: 2px 10px; border-radius: 999px; font-size: 0.74rem; font-weight: 700;
  margin-right: 6px; border:1px solid transparent; }
.b-high { background:#FDECEC; color:#B91C1C; border-color:#F8CACA; }
.b-medium { background:#FFF4E0; color:#B45309; border-color:#FBDDA6; }
.b-low { background:#E8F7EE; color:#15803D; border-color:#BDE7CC; }
.b-pending { background:#FFF7E6; color:#B45309; }
.b-progress { background:#E8EFFF; color:#1745C2; }
.b-completed { background:#E8F7EE; color:#15803D; }
.b-overdue { background:#DC2626; color:#FFFFFF; }
.b-cat { background:#EEF3FF; color:#1F3B8A; border-color:#D6E2FF; }
.b-ai { background: linear-gradient(135deg,#1F5EFF,#5B8CFF); color:#FFFFFF; }
.task-title { font-weight:700; color: var(--navy); font-size: 1.02rem; }
.task-desc { color: var(--muted); font-size: 0.9rem; margin: 2px 0 6px; }
.task-meta { color: var(--muted); font-size: 0.82rem; }
.task-meta b.overdue { color: var(--danger); }
.ai-box { background: linear-gradient(180deg,#F3F7FF,#FFFFFF); border:1px solid #D6E2FF; border-radius: 16px;
  padding: 1rem 1.1rem; margin-bottom: 0.8rem; }
.ai-head { font-weight:800; color: var(--brand-dark); font-size:0.95rem; margin-bottom: 4px; }
.ai-tag { font-size:0.7rem; font-weight:700; letter-spacing:.06em; text-transform:uppercase;
  padding:2px 8px; border-radius:6px; }
.tag-ml { background:#1F5EFF; color:#fff; }
.tag-rule { background:#0F1E3D; color:#fff; }
.notif { border-left: 4px solid var(--brand); background:#FFFFFF; border-radius: 10px; padding: 0.6rem 0.9rem;
  margin-bottom: 8px; border-top:1px solid var(--line); border-right:1px solid var(--line); border-bottom:1px solid var(--line); }
.notif.overdue { border-left-color: var(--danger); }
.notif.due_24h { border-left-color: var(--warning); }
.notif.reminder { border-left-color: #7C9CFF; }
.notif .when { color: var(--muted); font-size: 0.75rem; }

/* ---------- Auth page ---------- */
.hero { background: linear-gradient(135deg,#0F1E3D 0%,#1745C2 60%,#1F5EFF 100%); border-radius: 22px;
  padding: 2.4rem 2.2rem; color:#fff; min-height: 520px; position:relative; overflow:hidden; }
.hero::after { content:""; position:absolute; right:-80px; bottom:-80px; width:280px; height:280px;
  border-radius:50%; background: rgba(255,255,255,0.08); }
.hero h1 { color:#FFFFFF; font-size: 2.2rem; line-height:1.15; margin: 1rem 0 0.6rem; }
.hero p, .hero li { color:#DCE6FF; font-size: 0.98rem; }
.hero ul { padding-left: 1.1rem; margin-top: 1.2rem; }
.hero li { margin-bottom: 0.55rem; }

/* ---------- Widgets ---------- */
.stButton button[kind="primary"], .stFormSubmitButton button[kind="primary"] {
  background: var(--brand); border: none; font-weight: 700; border-radius: 10px;
  box-shadow: 0 6px 16px -8px rgba(31,94,255,0.8);
}
.stButton button[kind="primary"]:hover, .stFormSubmitButton button[kind="primary"]:hover { background: var(--brand-dark); }
.stButton button, .stDownloadButton button, .stFormSubmitButton button { border-radius: 10px; font-weight: 600; }
[data-testid="stVerticalBlockBorderWrapper"] { border-radius: 16px; }
div[data-testid="stExpander"] details { border-radius: 12px; border-color: var(--line); background: #fff; }
.stTabs [data-baseweb="tab-list"] { gap: 4px; }
.stTabs [data-baseweb="tab"] { font-weight: 600; }
[data-testid="stPlotlyChart"] { background:#FFFFFF; border:1px solid var(--line); border-radius:16px; padding: 6px; }
</style>
"""

PRIORITY_CLASS = {"High": "b-high", "Medium": "b-medium", "Low": "b-low"}
STATUS_CLASS = {"Pending": "b-pending", "In Progress": "b-progress",
                "Completed": "b-completed", "Overdue": "b-overdue"}


def esc(text) -> str:
    return html.escape(str(text if text is not None else ""))


def badge(text: str, css: str) -> str:
    return f'<span class="badge {css}">{esc(text)}</span>'


def priority_badge(p: str) -> str:
    return badge(f"{p} priority", PRIORITY_CLASS.get(p, "b-cat"))


def status_badge(s: str) -> str:
    return badge(s, STATUS_CLASS.get(s, "b-cat"))


def kpi(label: str, value, sub: str = "", accent: str = "#1F5EFF", primary: bool = False) -> str:
    cls = "kpi primary" if primary else "kpi"
    return (f'<div class="{cls}" style="--accent:{accent}"><div class="kpi-label">{esc(label)}</div>'
            f'<div class="kpi-value">{esc(value)}</div><div class="kpi-sub">{esc(sub)}</div></div>')


def page_header(title: str, subtitle: str = "") -> str:
    return (f'<div class="page-head"><div><div class="page-title">{esc(title)}</div>'
            f'<div class="page-sub">{esc(subtitle)}</div></div></div>')
